<?php
$total=0;
$i=0;
$aNum=0;
$lineType="";
$para=0;
$openDiv=false;
$i=0;
foreach ($surveyForm as $param_name => $param_val) {
	if ($i==0) {
	}
	else if ($i==1) {
		?>
			<div class="box square-box is-marginless">
				<h1 class="title is-size-3"><?php echo $param_val ?></h1>
			</div>
		<?php
	}
	else if ($i==2) {
		?>
		<div class="box square-box" style="min-height:200px" id="description">
			<p class="subtitle is-size-6">
				<?php echo $param_val ?>
			</p>
		</div>
		<?php
			if (!empty($tagString)) {
				foreach ($tags as $t => $tagname) {
				?>
					<a href="community.php?tag=<?php echo "$tagname"?>">
						<span class="tag is-success">
							<?php echo "#$tagname"?>
						</span>
					</a>
				<?php
				}
			}
		?>
		<center>
			<a href="#questionform" class="button is-rounded is-white"> 
				<img src="res/dropdown.png" alt="to survey" style="max-width:25px;max-height:25px; width: auto; height: auto;">
			</a>
		</center>
		<div id="questionform">
		</div>
		<?php
	}
	else if (fmod($i,2)==1) {
		$lineType=$param_val;
		if (substr($param_val,0,3) != "ans") $total++;
	}
	else if (fmod($i,2)==0) {
		if ($lineType=="yn") {
			$qdisplay = $total-$para;
			if ($openDiv) {
					?>
					</div>
					<?php
					$openDiv=false;
				}
			?>
				<div class="container dimdown">
					<p class="is-size-4 has-text-weight-light spaced-out-wide">
						<?php echo "<b> Question $qdisplay: </b> $param_val"; ?>
					</p>
					<p class="is-size-5 has-text-weight-light spaced-out-horizontal spaced-out-medium">
						<input type="hidden" name="<?php echo"q$total"?>[]" value="default value" style="display:none;"> </input><br>
						<input type="radio" name="<?php echo"q$total" ?>[]" value="1"> Yes </input> <br>
						<input type="radio" name="<?php echo"q$total" ?>[]" value="2"> No </input> <br>
					</p>
				</div>
			<?php
		}
		else if ($lineType=="none") {
			$para++;
			if ($openDiv) {
					?>
					</div>
					<?php
					$openDiv=false;
				}
			?>
				<div class="container spaced-out-wide">
					<p class="is-size-4 has-text-weight-light spaced-out-wide">
						<?php echo "<br/>$param_val<br/><br/>"; ?>
					</p>
					<p class="is-size-5 has-text-weight-light spaced-out-horizontal spaced-out-medium">
						<input type="hidden" name="<?php echo"q$total"?>" value="default value" style="display:none;"> </input><br>
					</p>
				</div>
			<?php
		}
		else if ($lineType=="rating") {
			$qdisplay = $total-$para;
			if ($openDiv) {
					?>
					</div>
					<?php
					$openDiv=false;
				}
			?>
				<div class="container dimdown">
					<p class="is-size-4 has-text-weight-light spaced-out-wide">
						<?php echo "<b> Question $qdisplay: </b> $param_val"; ?>
					</p>
					<p class="is-size-5 has-text-weight-light spaced-out-medium">
						<input type="number" min="1" max="10" name=<?php echo"q$total" ?> style="width:60px; height:25px"></input> 
						/ 10
						<span class="fa fa-star starchecked">
						</span>
						<br>
					</p>
				</div>
			<?php
		}
		else if ($lineType=="textbox") {
			$qdisplay = $total-$para;
			if ($openDiv) {
					?>
					</div>
					<?php
					$openDiv=false;
				}
			?>
				<div class="container dimdown">
					<p class="is-size-4 has-text-weight-light spaced-out-wide">
						<?php echo "<b> Question $qdisplay: </b> $param_val"; ?>
					</p>
					<p class="is-size-5 has-text-weight-light spaced-out-medium">
						<textarea class="textarea" name=<?php echo"q$total" ?> placeholder="Enter your answer..." style="resize: none;"></textarea> <br>
					</p>
				</div>
			<?php
		}
		else if ($lineType=="checkboxs" || $lineType=="multichoice") {
			$qdisplay = $total-$para;
			if ($openDiv) {
				?>
				</div>
				<?php
				$openDiv=false;
			}
			?>
				<div class="container dimdown">
					<p class="is-size-4 has-text-weight-light spaced-out-wide">
						<?php echo "<b> Question $qdisplay: </b> $param_val"; ?>
					</p>
					<p class="is-size-5 has-text-weight-light spaced-out-horizontal spaced-out-medium">
						<input type="hidden" name="<?php echo"q$total"?>[]" value="default value"> </input><br>
					</p>
			<?php
			$aNum=0;
			$openDiv=true;
		}
		else {
			$aNum++;
			?>
				<p class="is-size-5 has-text-weight-light spaced-out-horizontal spaced-out-medium">
					<input type= <?php echo substr($lineType,3);?> name="<?php echo"q$total"?>[]" value="<?php echo "$aNum";?>"> <?php echo $param_val;?> </input><br>
				</p>
			<?php
		}
	}
	$i++;
}
if ($openDiv) {
	?>
	</div>
	<?php
	$openDiv=false;
}
?>