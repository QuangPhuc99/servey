<?php
	session_start();
	if ($_SESSION['admin']==0) exit();
	if (isset($_GET['uID'])) {
		$uID=$_SESSION['id'];
		$con=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
		$id=$_GET['uID'];
		$q = "UPDATE `users` SET `isBanned`=!`isBanned` WHERE userID=$id;";
		$res = mysqli_query($con,$q);
		$q = "SELECT * FROM `users` WHERE userID= $id;";
		$res= mysqli_query($con,$q);
		$u= mysqli_fetch_array($res, MYSQLI_NUM);
		if ($u[6]!=0) {
			echo "<i class='fas'>&#xf3c1;</i>";
		}
		else {
			echo "<i class='fas'>&#xf023;</i>";
		}
	}
	else echo "???";
	mysqli_close($con);
?>