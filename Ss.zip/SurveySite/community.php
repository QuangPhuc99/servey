<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Community</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
			$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
		?>
		<!---->
		
		<!--Content-->
		<!--Welcome message-->
		<section class="section " id="welcome">
			<a href="community.php">
				<div class="container">
					<div class="media">
						<div class="media-left">
							<img src="res/lib.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
						</div>					
						<div class="media-content">
							<h1 class="title is-uppercase has-text-weight-light"> Community. </h1>
							<p class="has-text-grey">
								You scratch my back, I scratch yours.<br>
								Help our community grow by helping answer surveys from our website.
							</p>
						</div>
					</div>
				</div>
			</a>
		</section>
		<!--script-->
		<script src="formmakinggenerator.js">
		</script>
		<!--...-->
		<!--Dashboard-->
		<div class="columns has-background-light">
			<div class="column is-8 is-offset-2">
				<div class="is-marginless">
					<form>
						<input class="input" style="width: 50vw" placeholder="Search for surveys by username or title." name="search" required>
						<button class="button" type="submit"><i class="fa fa-search"></i></button>
						</input>
					</form>
					<form>
						<input class="input spaced-out-wide" style="width: 50vw" placeholder="Search for surveys by tags." name="tag" id="tags" required onblur="correctTag()">
						<button class="button spaced-out-wide" type="submit"><i class="fa fa-search"></i></button>
						</input>
					</form>
					<?php
						$page=1;
						$searchString='';
						$tagString='';
						if (isset($_GET['page'])){
							$page=$_GET['page'];
						}
						$offset=($page-1)*5;
						$title='Recent new surveys';
						//get all survey
						$query="SELECT * FROM `surveys` WHERE isDisable='0' AND `isLimited`='0' ORDER BY date DESC LIMIT 5;";
						$result= mysqli_query($conn,$query);
						$totalSurvey1=$result->num_rows;
						$maxpage= ceil($totalSurvey1/5);
						$query="SELECT * FROM `surveys` WHERE isDisable='0' AND isLimited='0' ORDER BY date DESC LIMIT 5;";
						$result= mysqli_query($conn,$query);
						//check if search is set. Reload result with survey with user name = search string.
						if (isset($_GET['search'])) {
							if (!empty($_GET['search'])){
								$searchString=$_GET['search'];
								$title= "Search result for username with \"$searchString\"";
								$searchString= mysqli_real_escape_string($conn,$searchString);
								$query="SELECT * FROM `surveys` s
								INNER JOIN `users` u ON u.userID=s.userID
								WHERE u.`username` LIKE '%$searchString%' 
								AND s.`isDisable`='0' 
								AND s.`isLimited`='0'
								ORDER BY date DESC;";
								$result= mysqli_query($conn,$query);
								$totalSurvey1=$result->num_rows;
								$maxpage= ceil($totalSurvey1/5);
								$query="SELECT * FROM `surveys` s
								INNER JOIN `users` u ON u.userID=s.userID
								WHERE u.`username` LIKE '%$searchString%' 
								AND s.`isDisable`='0' 
								AND s.`isLimited`='0'
								ORDER BY date DESC 
								LIMIT 5 OFFSET $offset;";
								$result= mysqli_query($conn,$query);
							}
						}
						//get totalsurvey for first part.
						$totalSurvey1=$result->num_rows;
					?>
						<h1 class="title is-size-3">
							<?php echo "$title";?>
						</h1>
					<?php
						//printing result for new survey if search isn't set or search result if search is set.
						for ($i=0; ($i<5) && ($i < $totalSurvey1); $i++) {
							$survey= mysqli_fetch_array($result, MYSQLI_NUM);
							$query="SELECT * FROM `questions` WHERE surveyID='$survey[0]' AND questionType <> 'none';";
							$q= mysqli_query($conn,$query);
							$totalQuestions= $q->num_rows;
							$query="SELECT * FROM `responses` WHERE surveyID='$survey[0]';";
							$r= mysqli_query($conn,$query);
							$totalRes = $r->num_rows;
							$tags= explode(" ",$survey[8]);
					?>
							<a href="surveyview.php?id=<?php echo $survey[0]; ?>">
								<article class="message spaced-out-wide is-dark dimdown">
									<div class="message-header">
										<h1 class="has-text-weight-bold is-size-5"><?php echo "$survey[1]" ;?></h1>
									</div>
									<div class="message-body">
										<p class="has-text-grey is-size-7"> Created: <?php echo "$survey[4]" ;?> | Survey ID: <?php echo "$survey[0]";?> 
										| Questions: <?php echo "$totalQuestions" ;?> | Responses: <?php echo "$totalRes" ;?></p>
										<p class="is-size-5">
											<?php echo "$survey[2]" ;?><br>
											<?php
												if (!empty($survey[8])) {
													foreach ($tags as $t => $tagname) {
													?>
														<span class="tag is-dark">
															<?php echo "#$tagname"?>
														</span>
													<?php
													}
												}
											?>
										</p>
									</div>
								</article>
							</a>
					<?php
						}
						//if search is set, load survey with all survey wher search = survey title.
						if (isset($_GET['search']) || isset($_GET['tag'])) {
							if (isset($_GET['search'])) {
								if (!empty($_GET['search'])){
									$searchString=$_GET['search'];
									$title= "Search result for survey title with \"$searchString\"";
									$searchString= mysqli_real_escape_string($conn,$searchString);
									$query="SELECT * FROM `surveys` s
										WHERE s.`title` LIKE '%$searchString%' 
										AND s.`isDisable`='0' 
										AND s.`isLimited`='0'
										ORDER BY date DESC;";
									$result= mysqli_query($conn,$query);
									$totalSurvey2=$result->num_rows;
									$maxpage2= ceil($totalSurvey2/5);
									$query="SELECT * FROM `surveys` s
										WHERE s.`title` LIKE '%$searchString%' 
										AND s.`isDisable`='0' 
										AND s.`isLimited`='0'
										ORDER BY date DESC 
										LIMIT 5 OFFSET $offset;";
									$result= mysqli_query($conn,$query);
									$totalSurvey2=$result->num_rows;
									if ($maxpage2>$maxpage) $maxpage=$maxpage2;
									$nextpage= $page+1;
									$prevpage= $page-1;
									if ($nextpage > $maxpage) {
										$nextpage --;
									}
									if ($prevpage == 0) {
										$prevpage ++;
									}
									?>
									<h1 class="title is-size-3">
										<?php echo "$title";?>
									</h1>
									<?php
										//print out all the surveys for search with title.
										for ($i=0; ($i<5) && ($i < $totalSurvey2); $i++) {
											$survey= mysqli_fetch_array($result, MYSQLI_NUM);
											$query="SELECT * FROM `questions` WHERE surveyID='$survey[0]' AND questionType <> 'none';";
											$q= mysqli_query($conn,$query);
											$totalQuestions= $q->num_rows;
											$query="SELECT * FROM `responses` WHERE surveyID='$survey[0]';";
											$r= mysqli_query($conn,$query);
											$totalRes = $r->num_rows;
											$tags= explode(" ",$survey[8]);
									?>
											<a href="surveyview.php?id=<?php echo $survey[0]; ?>">
												<article class="message spaced-out-wide is-success dimdown">
													<div class="message-header">
														<h1 class="has-text-weight-bold is-size-5"><?php echo "$survey[1]" ;?></h1>
													</div>
													<div class="message-body">
														<p class="has-text-grey is-size-7"> Created: <?php echo "$survey[4]" ;?> | Survey ID: <?php echo "$survey[0]";?> 
														| Questions: <?php echo "$totalQuestions" ;?> | Responses: <?php echo "$totalRes" ;?></p>
														<p class="is-size-5">
															<?php echo "$survey[2]" ;?><br>
															<?php
																if (!empty($survey[8])) {
																	foreach ($tags as $t => $tagname) {
																	?>
																		<span class="tag is-success">
																			<?php echo "#$tagname"?>
																		</span>
																	<?php
																	}
																}
															?>
														</p>
													</div>
												</article>
											</a>
									<?php
										}
										//close connection and display pages.
								}
							}
							if (isset($_GET['tag'])) {
								if (!empty($_GET['tag'])){
									$tagString=$_GET['tag'];
									$title= "Search result for tag \"$tagString\"";
									$tagArr= explode(" ",$tagString);
									$tagString= mysqli_real_escape_string($conn,$tagString);
									$query="SELECT * FROM `surveys` s
										WHERE ";
									foreach ($tagArr as $tagValue) {
										$tagValue= mysqli_real_escape_string($conn,$tagValue);
										$query .= "(s.`tags` LIKE '% $tagValue %' OR s.`tags` LIKE '$tagValue %' OR s.`tags` LIKE '% $tagValue' OR s.`tags` = '$tagValue') AND ";
									}
									$query .= " s.`isDisable`='0' 
										AND s.`isLimited`='0'
										ORDER BY date DESC;";
									$result= mysqli_query($conn,$query);
									$totalSurvey3=$result->num_rows;
									$maxpage3= ceil($totalSurvey3/5);
									$query="SELECT * FROM `surveys` s
										WHERE ";
									foreach ($tagArr as $tagValue) {
										$tagValue= mysqli_real_escape_string($conn,$tagValue);
										$query .= "(s.`tags` LIKE '% $tagValue %' OR s.`tags` LIKE '$tagValue %' OR s.`tags` LIKE '% $tagValue' OR s.`tags` = '$tagValue') AND ";
									}	
									$query.=" s.`isDisable`='0' 
										AND s.`isLimited`='0'
										ORDER BY date DESC 
										LIMIT 5 OFFSET $offset;";
									$result= mysqli_query($conn,$query);
									$totalSurvey3=$result->num_rows;
									if ($maxpage3>$maxpage) $maxpage=$maxpage3;
									$nextpage= $page+1;
									$prevpage= $page-1;
									if ($nextpage > $maxpage) {
										$nextpage --;
									}
									if ($prevpage == 0) {
										$prevpage ++;
									}
									?>
									<h1 class="title is-size-3">
										<?php echo "$title";?>
									</h1>
									<?php
										//print out all the surveys for search with title.
										for ($i=0; ($i<5) && ($i < $totalSurvey3); $i++) {
											$survey= mysqli_fetch_array($result, MYSQLI_NUM);
											$query="SELECT * FROM `questions` WHERE surveyID='$survey[0]' AND questionType <> 'none';";
											$q= mysqli_query($conn,$query);
											$totalQuestions= $q->num_rows;
											$query="SELECT * FROM `responses` WHERE surveyID='$survey[0]';";
											$r= mysqli_query($conn,$query);
											$totalRes = $r->num_rows;
											$tags= explode(" ",$survey[8]);
									?>
											<a href="surveyview.php?id=<?php echo $survey[0]; ?>">
												<article class="message spaced-out-wide is-info dimdown">
													<div class="message-header">
														<h1 class="has-text-weight-bold is-size-5"><?php echo "$survey[1]" ;?></h1>
													</div>
													<div class="message-body">
														<p class="has-text-grey is-size-7"> Created: <?php echo "$survey[4]" ;?> | Survey ID: <?php echo "$survey[0]";?> 
														| Questions: <?php echo "$totalQuestions" ;?> | Responses: <?php echo "$totalRes" ;?></p>
														<p class="is-size-5">
															<?php echo "$survey[2]" ;?><br>
															<?php
																if (!empty($survey[8])) {
																	foreach ($tags as $t => $tagname) {
																	?>
																		<span class="tag is-info">
																			<?php echo "#$tagname"?>
																		</span>
																	<?php
																	}
																}
															?>
														</p>
													</div>
												</article>
											</a>
									<?php
										}
										//close connection and display pages.
								}
							}
							?>
								<nav class="pagination" role="navigation" aria-label="pagination">
									
									<ul class="pagination-list">
										<li>
											<a class="pagination-previous has-background-white" href=<?php echo "community.php?page=1&search=$searchString&tag=$tagString"; ?>> 
												First
											</a>
										</li>
										<li>
											<span class="pagination-ellipsis">&hellip;</span>
										</li>
										<li>
											<?php
												if ($page!=$prevpage) {
													?>
													<a class="pagination-link has-background-white" href=<?php echo "community.php?page=$prevpage&search=$searchString&tag=$tagString"; ?>> 
														<?php echo "$prevpage"; ?>
													</a>
													<?php
												}
											?>
										</li>
										<li>
											<a class="pagination-link has-background-success" href=<?php echo "community.php?page=$page&search=$searchString&tag=$tagString"; ?>> 
												<?php echo "$page"; ?>
											</a>
										</li>
										<li>
											<?php
												if ($page!=$nextpage) {
													?>
													<a class="pagination-link has-background-white" href=<?php echo "community.php?page=$nextpage&search=$searchString&tag=$tagString"; ?>> 
														<?php echo "$nextpage"; ?>
													</a>
													<?php
												}
											?>
										</li>
										<li>
											<span class="pagination-ellipsis">&hellip;</span>
										</li>
										<li>
											<a class="pagination-next has-background-white" href=<?php echo "community.php?page=$maxpage&search=$searchString&tag=$tagString"; ?>>
												Last
											</a>
										</li>
									</ul>
								</nav>
							<?php
						}
					?>
					<a class="button has-text-weight-bold is-success spaced-out-wide" href="http://localhost/surveysite/createsurvey.php" style="border-style: solid; border-color: white; border-radius: 3px;">
						<img src="res/add.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
						<p> &nbsp Make a new survey</p>
					</a>
				</div>
			</div>
		</div>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<div class="columns has-background-light">
			<div class="column is-4 is-offset-2">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						About
						<img src="res/helpblack.png" alt="survey icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Learn more about surveys management tools<a class="title is-size-7 has-text-link has-text-weight-light" href="about.php"> here </a><br> 
					</p>
				</div>
			</div>
			<div class="column is-4">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						FAQ
						<img src="res/helpblack.png" alt="ans icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Something trouble you about our system? Check it <a class="title is-size-7 has-text-link has-text-weight-light" href="faq.php">here</a><br> 
					</p>
				</div>
			</div>
		</div>
		<!---->
		<!--Footer-->
		<!--include footer here-->
		<?php 
			mysqli_close($conn);
			include("footer.php");
		?>
		<!---->
	<body>
</html>