<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Dashboard</title>
	</head>
	<body>
		<!--Header-->
		<?php
			//add header
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
			//get page value
			$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
			$userID=$_SESSION['id'];
			$query="SELECT * FROM `surveys` WHERE isDisable='0' AND userID='$userID'";
			$result= mysqli_query($conn,$query);
			$totalSurvey= $result->num_rows;
			$query = "SELECT * from `responses` r INNER JOIN `surveys` s ON r.surveyID=s.surveyID WHERE s.isDisable='0' AND r.userID='$userID'";
			$result = mysqli_query($conn,$query);
			$totalResponses= $result->num_rows;
			$query = "SELECT * from `surveys` s INNER JOIN `responses` r ON r.surveyID=s.surveyID WHERE s.isDisable='0' AND s.userID = '$userID'";
			$result = mysqli_query($conn,$query);
			$totalResponsesGet= $result->num_rows;
			$query = "SELECT * from `surveys` s INNER JOIN `responses` r ON r.surveyID=s.surveyID GROUP BY s.surveyID HAVING s.isDisable='0' AND s.userID = '$userID';";
			$result = mysqli_query($conn,$query);
			$totalHaveResponses= $result->num_rows;
		?>
		<!---->
		
		<!--Content-->
		<!--Welcome message-->
		<section class="section " id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left desktop">
						<img src="res/hello.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> Hello! <?php echo $_SESSION['name']?>. </h1>
						<p class="has-text-grey">
							Welcome back, <span class="is-capitalized"><?php echo $_SESSION['name']?></span>!<br> 
							Start making your survey now by clicking on "Making a new survey".<br>
						</p>
					</div>
				</div>
			</div>
		</section>
		<!--Dashboard-->
		<section class="hero has-background-light" id="static">
			<div class="hero-body">
				<!--User Statistics-->
				<div class="columns">
					<div class="column is-8 is-offset-2">
						<h1 class="title is-size-3">
							Statistics
						</h1>
					</div>
				</div>
				<div class="columns">
					<div class="column is-2 is-offset-2">
						<div class="box square-box">
							<h1 class="has-text-grey has-text-weight-light is-size-5">
								Total surveys
								<img src="res/paper.png" alt="survey icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
							</h1>
							<p class="has-text-grey is-size-7">
								<br>You have created <?php echo "$totalSurvey" ?> survey(s) on this website.<br> 
							</p>
						</div>
					</div>
					<div class="column is-2">
						<div class="box square-box">
							<h1 class="has-text-grey has-text-weight-light is-size-5">
								Total answers
								<img src="res/check.png" alt="ans icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
							</h1>
							<p class="has-text-grey is-size-7">
								<br>You have answered <?php echo "$totalResponses" ?> survey(s) from this website.<br> 
							</p>
						</div>
					</div>
					<div class="column is-2">
						<div class="box square-box">
							<h1 class="has-text-grey has-text-weight-light is-size-5">
								Total responses
								<img src="res/check.png" alt="ans icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
							</h1>
							<p class="has-text-grey is-size-7">
								<br>Your surveys have recieved <?php echo "$totalResponsesGet" ?> response(s).<br> 
							</p>
						</div>
					</div>
					<div class="column is-2">
						<div class="box square-box">
							<h1 class="has-text-grey has-text-weight-light is-size-5">
								Not answered
								<img src="res/idle.png" alt="idle icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
							</h1>
							<p class="has-text-grey is-size-7">
								<br>You have <?php $totalNotAns= $totalSurvey-$totalHaveResponses; echo "$totalNotAns" ?> survey(s) waiting to be answered.<br> 
							</p>
						</div>
					</div>
				</div>
				<!--Surveys-->
				<div class="columns">
					<div class="column is-8 is-offset-2">
						<h1 class="title is-size-3">
							Recent surveys <a href="mysurvey.php"><span class="title is-size-7 has-text-link has-text-weight-light">See all</span></a>
						</h1>
						<!--surveyview?id=?-->
						<?php
							$query="SELECT * FROM `surveys` WHERE isDisable='0' AND userID='$userID' ORDER BY date DESC;";
							$result= mysqli_query($conn,$query);
							if ($result->num_rows==0) {
							?>
								<div class="square-box has-background-light">
									<article class="media">
										<div class="media-content">
											<div class="content">
												<h1 class="has-text-weight-bold is-size-5">_No survey created_</h1>
												<p class="has-text-grey is-size-7"> Created: ____-__-__ __:__:__ | Survey ID: _ </p>
											</div>
										</div>
										<div class="media-right">
											<div class="columns">
												<center>
													<div class="column has-vertical-line">
														<h1 class="is-size-6">Questions</h1>
														<p class="has-text-grey is-size-5 center"> __</p>
													</div>
												</center>
												<center>
												<div class="column has-vertical-line">
													<h1 class="is-size-6">Responses</h1>
													<p class="has-text-grey is-size-5 center"> ___</p>
												</div>
												</center>
											</div>
										</div>
									</article>
								</div>
							<?php
							}
							for ($i=0; ($i<5) && ($i < $totalSurvey); $i++) {
								$survey= mysqli_fetch_array($result, MYSQLI_NUM);
								$query="SELECT * FROM `questions` WHERE surveyID='$survey[0]' AND questionType <> 'none';";
								$q= mysqli_query($conn,$query);
								$totalQuestions= $q->num_rows;
								$query="SELECT * FROM `responses` WHERE surveyID='$survey[0]';";
								$r= mysqli_query($conn,$query);
								$totalRes = $r->num_rows;
								$getVal="$survey[0]";
								if ($survey[6] == 1) {
									$getVal= "$survey[0]&key=$survey[7]";
								}
						?>
								<a href="surveyview.php?id=<?php echo $getVal; ?>"> 
									<div class="square-box">
										<article class="media">
											<div class="media-content">
												<div class="content">
													<h1 class="has-text-weight-bold is-size-5"><?php echo "$survey[1]" ;?></h1>
													<p class="has-text-grey is-size-7"> Created: <?php echo "$survey[4]" ;?> | Survey ID: <?php echo "$survey[0]";?> </p>
												</div>
											</div>
											<div class="media-right">
												<div class="columns">
													<center>
														<div class="column has-vertical-line">
															<h1 class="is-size-6">Questions</h1>
															<p class="has-text-grey is-size-5 center"> <?php echo "$totalQuestions" ;?></p>
														</div>
													</center>
													<center>
														<div class="column has-vertical-line">
															<h1 class="is-size-6">Responses</h1>
															<p class="has-text-grey is-size-5 center"> <?php echo "$totalRes" ;?></p>
														</div>
													</center>
												</div>
											</div>
										</article>
									</div>
								</a>
						<?php
							}
							mysqli_close($conn);
						?>
					</div>
				</div>
				<div class="column is-8 is-offset-2">
					<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/createsurvey.php" style="border-style: solid; border-color: white; border-radius: 3px;">
						<img src="res/add.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
						<p> &nbsp Make a new survey</p>
					</a>
					<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/community.php" style="border-style: solid; border-color: white; border-radius: 3px;">
						<img src="res/user.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
						<p> &nbsp Community</p>
					</a>
					<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/resReview.php" style="border-style: solid; border-color: white; border-radius: 3px;">
						<i class="fas fa-eye" style="max-width:15px;max-height:15px; width: auto; height: auto;"> </i>
						<p> &nbsp Responses review</p>
					</a>
					<?php 
					if ($_SESSION['admin']) {
					?>
						<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/viewAll.php" style="border-style: solid; border-color: white; border-radius: 3px;">
							<img src="res/admin.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
							<p> &nbsp Admin board</p>
						</a>
					<?php
					}
					?>
				</div>
			</div>
		</section>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--Footer-->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<?php
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
		?>
		<!---->
	<body>
</html>