var totalTextBox=0; //total of textbox required user to enter (questions and optional answers)
var numberOfQuestions=0; //total of question created
var para = 0; //total of paragraph
//adding another radio answer to multichoice question.
function addRadioAns(question) {
	//creating a new box
	totalTextBox++;
	var node = document.getElementById(question);
	node.numberOfAnswer++;
	//this radio button is disabled and will not be included in the final post method.
	var radio = document.createElement("input");
	radio.classList.add("radio");
	radio.classList.add("spaced-out");
	radio.type="radio";
	radio.name="option";
	radio.disabled=true;
	//adding question input box. This will be send through post method when user hit make survey.
	var textbox = document.createElement("input");
	textbox.classList.add("input");
	textbox.classList.add("spaced-out");
	textbox.type="text";
	textbox.name="Q"+question+"A"+node.numberOfAnswer;
	textbox.id="Q"+question+"A"+node.numberOfAnswer;
	textbox.placeholder="Add answer here...";
	textbox.required=true;
	//this mark the ans type as radio.
	var mark = document.createElement("input");
	mark.type="hidden";
	mark.name="ans" + question + " " + node.numberOfAnswer;
	mark.value="ansradio";
	//add everything in the form.
	node.appendChild(mark);
	node.appendChild(radio);
	node.appendChild(textbox);
}
function addRadioText(question,value) {
	//creating a new box
	totalTextBox++;
	var node = document.getElementById(question);
	node.numberOfAnswer++;
	//this radio button is disabled and will not be included in the final post method.
	var radio = document.createElement("input");
	radio.classList.add("radio");
	radio.classList.add("spaced-out");
	radio.type="radio";
	radio.name="option";
	radio.disabled=true;
	//adding question input box. This will be send through post method when user hit make survey.
	var textbox = document.createElement("input");
	textbox.classList.add("input");
	textbox.classList.add("spaced-out");
	textbox.type="text";
	textbox.name="Q"+question+"A"+node.numberOfAnswer;
	textbox.id="Q"+question+"A"+node.numberOfAnswer;
	textbox.placeholder="Add answer here...";
	textbox.value=value;
	textbox.required=true;
	//this mark the ans type as radio.
	var mark = document.createElement("input");
	mark.type="hidden";
	mark.name="ans" + question + " " + node.numberOfAnswer;
	mark.value="ansradio";
	//add everything in the form.
	node.appendChild(mark);
	node.appendChild(radio);
	node.appendChild(textbox);
}
//adding another checkbox answer to checkboxs question.
function addCheckboxAns(question) {
	//creating a new box
	totalTextBox++;
	var node = document.getElementById(question);
	node.numberOfAnswer++;
	//this checkbox button is disabled and will not be included in the final post method.
	var checkbox = document.createElement("input");
	checkbox.classList.add("checkbox");
	checkbox.classList.add("spaced-out");
	checkbox.type="checkbox";
	checkbox.name="option";
	checkbox.disabled=true;
	//adding question input box. This will be send through post method when user hit make survey.
	var textbox = document.createElement("input");
	textbox.classList.add("input");
	textbox.classList.add("spaced-out");
	textbox.type="text";
	textbox.name="Q"+question+"A"+node.numberOfAnswer;
	textbox.id="Q"+question+"A"+node.numberOfAnswer;
	textbox.placeholder="Add answer here...";
	textbox.required=true;
	//this mark the ans type as checkbox.
	var mark = document.createElement("input");
	mark.type="hidden";
	mark.name="ans" + question + " " + node.numberOfAnswer;
	mark.value="anscheckbox";
	//add everything in the form.
	node.appendChild(mark);
	node.appendChild(checkbox);
	node.appendChild(textbox);
}
//set a base for Multichoice question. (MUST HAVE AT LEAST 1 ANS).
function setMultiChoice() {
	addQuestion("multichoice");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	var addOpt = document.createElement("a");
	addOpt.classList.add("button");
	addOpt.classList.add("is-small");
	addOpt.classList.add("is-success");
	addOpt.style="display:block";
	addOpt.questionNo=numberOfQuestions;
	addOpt.onclick= function () {addRadioAns(this.questionNo)};
	var text = document.createTextNode("Add an answer");
	addOpt.appendChild(text);
	node.appendChild(addOpt);
	addRadioAns(numberOfQuestions);
}
//set a simple rating question.
function setSimpleRating() {
	addQuestionText("multichoice","Overall, how would you rate _______?");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	var addOpt = document.createElement("a");
	addOpt.classList.add("button");
	addOpt.classList.add("is-small");
	addOpt.classList.add("is-success");
	addOpt.style="display:block";
	addOpt.questionNo=numberOfQuestions;
	addOpt.onclick= function () {addRadioAns(this.questionNo)};
	var text = document.createTextNode("Add an answer");
	addOpt.appendChild(text);
	node.appendChild(addOpt);
	addRadioText(numberOfQuestions,"Excellent");
	addRadioText(numberOfQuestions,"Very good");
	addRadioText(numberOfQuestions,"Good");
	addRadioText(numberOfQuestions,"Fair");
	addRadioText(numberOfQuestions,"Poor");
}
//set a simple rating question.
function setGradeRating() {
	addQuestion("rating");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	var star1 = document.createElement("span");
	star1.classList.add("fa");
	star1.classList.add("fa-star");
	star1.classList.add("starchecked");
	var textbox = document.createElement("input");
	textbox.classList.add("input");
	textbox.style="width:60px; height:25px";
	textbox.type="number";
	textbox.min="1";
	textbox.max="10";
	textbox.value="10";
	textbox.disabled=true;
	var textans = document.createTextNode(" / 10 ");
	node.appendChild(textbox);
	node.appendChild(textans);
	node.appendChild(star1);
}
//set a Recommend question
function setSimpleRecommend() {
	addQuestionText("multichoice","How likely would you recommend _______?");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	var addOpt = document.createElement("a");
	addOpt.classList.add("button");
	addOpt.classList.add("is-small");
	addOpt.classList.add("is-success");
	addOpt.style="display:block";
	addOpt.questionNo=numberOfQuestions;
	addOpt.onclick= function () {addRadioAns(this.questionNo)};
	var text = document.createTextNode("Add an answer");
	addOpt.appendChild(text);
	node.appendChild(addOpt);
	addRadioText(numberOfQuestions,"1 NOT AT ALL LIKELY");
	addRadioText(numberOfQuestions,"2");
	addRadioText(numberOfQuestions,"3");
	addRadioText(numberOfQuestions,"4");
	addRadioText(numberOfQuestions,"5 EXTREMELY LIKELY");
}
//set a Yes No question. Auto add answers.
function setYNQuestion() {
	addQuestion("yn");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	//add yes no radio button. This is just a representation and will not be sent by post method.
	var yes = document.createElement("input");
	yes.classList.add("radio");
	yes.classList.add("spaced-out");
	yes.type="radio";
	yes.name="option";
	yes.disabled=true;
	node.appendChild(yes);
	var textY = document.createTextNode(" Yes");
	node.appendChild(textY);
	var no = document.createElement("input");
	no.classList.add("radio");
	no.classList.add("spaced-out");
	no.type="radio";
	no.name="option";
	no.disabled=true;
	node.appendChild(no);
	var textN = document.createTextNode(" No");
	node.appendChild(textN);
}
//set a base for checkbox question. (MUST HAVE AT LEAST 1 ANS).
function setCheckboxs() {
	addQuestion("checkboxs");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	var addOpt = document.createElement("a");
	addOpt.classList.add("button");
	addOpt.classList.add("is-small");
	addOpt.classList.add("is-success");
	addOpt.style="display:block";
	addOpt.questionNo=numberOfQuestions;
	addOpt.onclick= function () {addCheckboxAns(this.questionNo)};
	var text = document.createTextNode("Add an answer");
	addOpt.appendChild(text);
	node.appendChild(addOpt);
	addCheckboxAns(numberOfQuestions);
}
//set a textbox question. Auto add answers.
function setTextbox() {
	addQuestion("textbox");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	// This is just a representation and being disabled. This will not be added to final.
	var textbox = document.createElement("input");
	textbox.classList.add("input");
	textbox.classList.add("spaced-out");
	textbox.type="text";
	textbox.placeholder="Client answers here...";
	textbox.disabled=true;
	node.appendChild(textbox);
}
function setParagraph() {
	addQuestion("none");
	var node = document.getElementById(numberOfQuestions);
	node.numberOfAnswer=0;
	node.ispara=1;
	para ++;
}
//Create textbox for type in question.
function addQuestion(questionType) {
	numberOfQuestions++;
	totalTextBox++;
	//creating a new div box
	var node = document.createElement("div");
	node.classList.add('notification');
	node.classList.add('has-background-white');
	//set question id
	node.id=numberOfQuestions;
	//creat line indicate question number.
	var qtemp = numberOfQuestions - para;
	var textnode = document.createTextNode("Question "+qtemp+ ":");
	var textans = document.createTextNode("Answer: ");
	textans.style="display: block;";
	//create mark for each question type depend on the parameter.
	var questionbox = document.createElement("input");
	var mark = document.createElement("input");
	mark.type="hidden";
	mark.id="qmark" + numberOfQuestions;
	mark.name="questionType" + numberOfQuestions;
	mark.value=questionType;
	//creating question box for entering question.
	questionbox.classList.add("input");
	questionbox.classList.add("spaced-out");
	node.classList.add("spaced-out");
	questionbox.type="text";
	questionbox.name="Q"+numberOfQuestions;
	questionbox.placeholder="Your question here...";
	questionbox.id="Q"+numberOfQuestions;
	questionbox.required=true;
	//add everything into the question box and add it to the site
	node.appendChild(mark);
	if (questionType!="none") {
		node.appendChild(textnode);
	}
	node.appendChild(questionbox);
	if (questionType!="none") {
		node.appendChild(textans);
	}
	document.getElementById("question form").appendChild(node);
}
function addQuestionText(questionType,textQ) {
	numberOfQuestions++;
	totalTextBox++;
	//creating a new div box
	var node = document.createElement("div");
	node.classList.add('notification');
	node.classList.add('has-background-white');
	//set question id
	node.id=numberOfQuestions;
	//creat line indicate question number.
	var qtemp = numberOfQuestions - para;
	var textnode = document.createTextNode("Question "+qtemp + ":");
	var textans = document.createTextNode("Answer: ");
	textans.style="display: block;";
	//create mark for each question type depend on the parameter.
	var questionbox = document.createElement("input");
	var mark = document.createElement("input");
	mark.type="hidden";
	mark.id="qmark" + numberOfQuestions;
	mark.name="questionType" + numberOfQuestions;
	mark.value=questionType;
	//creating question box for entering question.
	questionbox.classList.add("input");
	questionbox.classList.add("spaced-out");
	node.classList.add("spaced-out");
	questionbox.type="text";
	questionbox.name="Q"+numberOfQuestions;
	questionbox.placeholder="Your question here...";
	questionbox.id="Q"+numberOfQuestions;
	questionbox.required=true;
	questionbox.value=textQ;
	//add everything into the question box and add it to the site
	node.appendChild(mark);
	node.appendChild(textnode);
	node.appendChild(questionbox);
	node.appendChild(textans);
	document.getElementById("question form").appendChild(node);
}
//remove the most recent question.
function undo() {
	if (numberOfQuestions>0) 
	{
		var node = document.getElementById(numberOfQuestions);
		if (node.ispara==1) para--;
		node.parentNode.removeChild(node);
		numberOfQuestions--;
		totalTextBox-= (node.numberOfAnswer + 1);
	}
}

function correctTag() {
	var node = document.getElementById("tags");
	var str = node.value;
	str = str.replace(/(^\s*)|(\s*$)/gi,"");
	str = str.replace(/[ ]{2,}/gi," ");
	str = str.replace(/\n /,"\n");
	str = str.replace(/[^a-zA-Z0-9 ]/g, '');
	var arr = str.split(" ");
	var result = [];
	for (var i = 0; i< arr.length ; i++) {
		if(result.indexOf(arr[i]) == -1) result.push(arr[i]);
	}
	result=result.join(" ");
	node.value= result;
}