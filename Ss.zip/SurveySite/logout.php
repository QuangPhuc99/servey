<?php
	session_start();
	setcookie("username", "", time()-60, "/","", 0);
	setcookie("password", "", time()-60, "/","", 0);
	unset($_SESSION["username"]);
	unset($_SESSION["password"]);
	session_destroy();
	header('location: default.php');
?>