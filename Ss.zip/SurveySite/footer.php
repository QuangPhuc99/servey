	</div>
	<div class="hero-foot has-background-success" id="footer">
		<div class="columns is-mobile is-marginless">
			<div class="column has-vertical-line is-offset-1 is-7 has-text-white">
				<a href="faq.php">
					Help 
				</a>
				|
				<a href="about.php#team">
					Developer Team
				</a>
				|
				<a href="about.php#aboutss">
					About Survey Site 
				</a>
				|
				<a href="community.php">
					Community
				</a>
				|
				<a href="mailto:trandaomanh1911@gmail.com">
					Mail us 
				</a>
				<p class="has-text-black">
					2019 - Developed by Group 12.<br><br>
				</p>
			</div>
			<div class="column is-3 right has-vertical-right">
				<a href="default.php">
					<img src="res/logo-with-name-black.png" style="max-height:40px; opacity: 0.2;">
				</a>
			</div>
		</div>
	</div>
</section>