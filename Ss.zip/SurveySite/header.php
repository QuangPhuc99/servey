<?php
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['valid'] = true;
		$_SESSION['username'] = $_COOKIE['username'];
		//set other info in session
		$username=$_SESSION['username'];
		$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
		$query="SELECT userID, username, password, name, isAdmin, isBanned FROM `users` WHERE userName='$username'";
		$result=mysqli_query($conn,$query);
		$user = mysqli_fetch_array($result, MYSQLI_NUM);
		$_SESSION['id'] = $user[0];
		$_SESSION['name'] = $user[3];
		$_SESSION['admin'] = $user[4];
		$_SESSION['rememberme'] = "remember";
		if ($user[5]) {
			header( 'location: logout.php');
		}
		setcookie("username", $_SESSION['username'], time()+86400*60, "/","", 0);
	}
?>
<section class="hero" id="header">
	<div class="hero-head has-background-success is-bold">
		<div class="columns is-mobile heading has-text-weight-bold">
			<!--Left side column-->
			<div class="column left">
				<?php
					if (!isset($_SESSION['username'])) {
				?>
				<figure class="navbar-item image">
					<a href="http://localhost/surveysite/">
						<img src="res/logo-with-name.png" alt="logo with name" style="max-width:250px;max-height:50px; width: auto; height: auto;">
					</a>
				</figure>
				<?php
					}
					else {
				?>
				<figure class="navbar-item image">
					<a href="http://localhost/surveysite/dashboard.php">
						<img src="res/logo.png" alt="logo" style="max-width:40px;max-height:30px; width: auto; height: auto;">
					</a>
				</figure>
				<a class="navbar-item button is-success is-size-7 desktop" href="dashboard.php">
					Dashboard
				</a>
				<a class="navbar-item button is-success is-size-7 desktop" href="mysurvey.php">
					My Surveys
				</a>
				<a class="navbar-item button is-size-7" href="http://localhost/surveysite/createsurvey.php" style="border-style: solid; border-color: white; border-radius: 3px;">
					Make a new survey
				</a>
				<?php
					}
				?>
			</div>
			<!--...-->
			<!--Right side column-->
			<div class="column center desktop">
				<?php
					if (!isset($_SESSION['username'])) {
				?>
				<a class="navbar-item button is-success is-size-6" href="http://localhost/surveysite/default.php">
					Getting Started
				</a>
				<a class="navbar-item button is-success is-size-6" href="http://localhost/surveysite/about.php">
					Learn more
				</a>
				<a class="navbar-item button is-success is-size-6" href="#footer">
					Contact us
				</a>
				<?php
					}
				?>
			</div>
			<div class="column right desktop">
				<?php
					if (isset($_SESSION['username'])) {
				?>
				<!--Contactinfo-->
				<a class="button is-success" href="#footer">
					<img src="res/contact.png" alt="contact" style="max-width:30px;max-height:25px; width: auto; height: auto;">
				</a>
				<!--Help-->
				<a class="button is-success" href="http://localhost/surveysite/faq.php">
					<img src="res/help.png" alt="help" style="max-width:30px;max-height:25px; width: auto; height: auto;">
				</a>
				<!--Account setting-->
				<a class="button is-success" href="http://localhost/surveysite/setting.php">
					<img src="res/user.png" alt="account" style="max-width:30px;max-height:25px; width: auto; height: auto;">
				</a>
				<a class="navbar-item button is-success is-size-7" href="logout.php">
					Log out 
				</a>
				<?php
					}
					else {
				?>
				<a class="navbar-item button is-size-6" href="signup.php" style="border-style: solid; border-color: white; border-radius: 3px;">
					Sign up
				</a>
				<a class="navbar-item button is-success is-size-6" href="login.php">
					Log in
				</a>
				<?php
					}
				?>
			</div>
			<!--...-->
			<!--Dropdown menu-->
			<div class="column right tablet">
				<div class="navbar-item is-active dropdown is-right">
					<!--Dropdown trigger-->
					<div class="dropdown-trigger">
						<button class="button" aria-haspopup="true" aria-controls="dropdown-menu" onclick="toggleDisplayTrigger()" style="max-width:50px;max-height:50px; width: auto; height: auto;">
							<span>
								<figure class="image">
									<img src="res/menu-256.png" alt="hamburger menu">
								</figure>
							</span>
						</button>
					</div>
					<!--...-->
					<!--Dropdown menu-->
					<div class="dropdown-menu" id="dropdown-menu" role="menu">
						<div class="dropdown-content">
							<?php
								if (isset($_SESSION['username'])) {
							?>
							<a class="dropdown-item" href="dashboard.php">
								Dashboard
							</a>
							<a class="dropdown-item" href="mysurvey.php">
								My Surveys
							</a>
							<a class="dropdown-item" href="#footer">
								Contact us
							</a>
							<a class="dropdown-item" href="faq.php">
								Help
							</a>
							<a class="dropdown-item" href="setting.php">
								Account setting
							</a>
							<a class="dropdown-item red" href="logout.php">
								Log out
							</a>
							<?php
								}
								else {
							?>
							<a class="dropdown-item" href="#footer">
								Contact us
							</a>
							<a class="dropdown-item" href="about.php">
								Learn more
							</a>
							<a class="dropdown-item red" href="signup.php">
								Sign up
							</a>
							<a class="dropdown-item green" href="login.php">
								Log in
							</a>
							<?php
								}
							?>
						</div>
					</div>
					<!--...-->
					<!--script for dropmenu trigger-->
					<script type="text/javascript">
					function toggleDisplayTrigger() {
						var menu= document.getElementById("dropdown-menu");
						if (menu.style.visibility === "hidden") {
							menu.style.visibility = "visible";
						}
						else {
							menu.style.visibility = "hidden";
						}
					}
					</script>
					<!--...-->
				</div>
			</div>
			<!--...-->
		</div>
	</div>
	<div class="hero-body is-paddingless main-section">
