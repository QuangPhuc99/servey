<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Welcome to Survey Site! </title>
	</head>
	<body>
		<!--Header-->
		<?php
			include("redirect1.php");
			include("header.php");
		?>
		<!---->
		
		<!--content-->
		<section id="content">
			<div style="min-height: 100vh;">
				<div class="columns">
					<div class="column">
						<article class="media notification is-white center">
							<div class="media-content">
								<div class="content">
									<center>
									<br> <br>
									<h1 class="title is-size-1">
										<b> WELCOME TO SURVEY SITE </b><br>
									</h1>
									<p class="is-size-6 has-text-grey-light">
										Welcome to Survey Site!
										Start creating your own survey easy and effective using our tools. <br>
										To begin click "Sign up" to create a new account or click "Log in" to use your existed account.<br>
									</p>
									</center>
								</div>
							</div>
						</article>
					</div>
				</div>
				<center>
					<div class="container">
						<center>
							<a class="button is-large is-warning is-rounded" href="http://localhost/surveysite/signup.php">
								&nbsp &nbsp &nbsp Sign up &nbsp &nbsp &nbsp
							</a>
						</center>
					</div>
					<br>
					<div class="container">
						<center>
							<a class="button is-large is-success is-outlined is-rounded" href="http://localhost/surveysite/login.php">
								&nbsp &nbsp &nbsp Log in &nbsp &nbsp &nbsp
							</a>
						</center>
					</div>
				
				</center>
			</div>
		</section>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="back-to-top" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	<body>
</html>