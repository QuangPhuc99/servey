<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.1/jquery.min.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>My Responses</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
			$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
			$userID = $_SESSION['id'];
			$query="SELECT * FROM `responses` WHERE `userID`=$userID ORDER BY `date` DESC";
			$result= mysqli_query($conn,$query);
			$totalSurveyAns= $result->num_rows;
		?>
		<!---->
		
		<!--Content-->
		<!--Welcome message-->
		<section class="section " id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/lib.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> Your responses. </h1>
						<p class="has-text-grey">
							This is your survey responses list.<br>
							Here you can review all of your responses.
						</p>
					</div>
				</div>
			</div>
		</section>
		<!--Dashboard-->
		<div class="columns has-background-light">
			<div class="column is-8 is-offset-2">
				<div class="is-marginless">
					<h1 class="is-size-3 has-text-weight-light spaced-out"> All responses </h1>
					<p class="is-size-6 has-text-weight-light spaced-out"> 
						Total survey answered: <?php echo "$totalSurveyAns" ?>
					</p>
					<table class="table is-hoverable is-fullwidth is-striped" style="border: 1px solid;">
						<thead>
							<tr>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Survey ID</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Survey Title</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Questions</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Date</th>
								<th class="has-background-dark has-text-white">Details</th>
							</tr>
						</thead>
						<tbody>
							<!--script-->
							<script>
								function displayDetails(n) {
									var xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
										if (this.readyState == 4 && this.status == 200) {
											document.getElementById("details").innerHTML = this.responseText;
										}
									};
									xhttp.open("GET", "getRes.php?rid="+n+"&uid="+<?php echo $_SESSION['id'] ?>, true);
									xhttp.send();
								}
							</script>
							<!--...-->
							<?php
								$detail = [];
								$query="SELECT * FROM `responses` WHERE userID='$userID' ORDER BY date DESC;";
								$result= mysqli_query($conn,$query);
								if ($result->num_rows==0) {
							?>
									<tr>
										<td>
											__
										</td>
										<td>
											__
										</td>
										<td>
											__
										</td>
										<td>
											____-__-__ __:__:__
										</td>
										<td>
											__
										</td>
									</tr>
							<?php
								} else
								{
									$n=0;
									while ($row = mysqli_fetch_array($result,MYSQLI_NUM)) {
										$surveyID=$row[2];
										$resID = $row[0];
										$query="SELECT * FROM `surveys` WHERE surveyID='$surveyID'";
										$title= mysqli_query($conn,$query);
										$svTitle= mysqli_fetch_array($title, MYSQLI_NUM)[1];
										$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' AND questionType <> 'none'";
										$question= mysqli_query($conn,$query);
										$totalQuestions= $question->num_rows;
										$n++;
										echo "
										<tr>
											<td>
												$row[2]
											</td>
											<td>
												$svTitle
											</td>
											<td>
												$totalQuestions
											</td>
											<td>
												$row[3]
											</td>
											<td>
												<a class='button' onclick='displayDetails($resID)'>
													<span class='fas fa-file-alt'>
													</span>
												</a>
											</td>
										</tr>";
									}
								}
							?>
						</tbody>
					</table>
					<h1 class="is-size-3 has-text-weight-light spaced-out"> Details </h1>
					<div id="details">
					</div>
				</div>
			</div>
		</div>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<div class="columns has-background-light">
			<div class="column is-4 is-offset-2">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						About
						<img src="res/helpblack.png" alt="survey icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Learn more about surveys management tools<a class="title is-size-7 has-text-link has-text-weight-light" href="about.php"> here </a><br> 
					</p>
				</div>
			</div>
			<div class="column is-4">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						FAQ
						<img src="res/helpblack.png" alt="ans icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Something trouble you about our system? Check it <a class="title is-size-7 has-text-link has-text-weight-light" href="faq.php">here</a><br> 
					</p>
				</div>
			</div>
		</div>
		<!---->
		<!--Footer-->
		<!--include footer here-->
		<?php
			mysqli_close($conn);
			include("footer.php");
		?>
		<!---->
	<body>
</html>