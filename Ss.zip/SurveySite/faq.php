<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Help</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
		?>
		<!---->
		
		<!--content-->
		<!--Title goes here-->
		<section class="section " id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/helpblack.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> HELP. </h1>
						<p class="has-text-grey">
							Having trouble with our website? <br>
							Find your answers here from our Tutorial and FAQ. <br>
							If you still can't find your answer. 
							<a class="has-text-black" href="mailto:trandaomanh1911@gmail.com"> Send us a message. </a>
						</p>
					</div>
				</div>
			</div>
		</section>
		<!--Content goes here-->
		<section class="hero has-background-light" id="static">
			<div class="hero-body">
				<!--content tutorial: how to make a survey, how to share a survey, how to analyze a survey. -->
				<!--Content including a "tutorial" title, 3 subtitles and 3 paragraphs,one for each subtitle-->
				<!--content about faq: currently empty. only need the frame. Content including a title and a paragraph-->
				<!--NOTE: Add a side menu for easier find in this document. Check link for ref: https://bulma.io/documentation/components/menu/	-->
				<!--NOTE: Add id number for easier references"-->
				<!--NOTE: Tab in 1/12 screen size on both left and right-->
				<!--NOTE: Less is more! Make it simple yet easy to read-->
				<!--CAN REUSE CODE FROME ABOUT FOR EASIER TIME CODING SINCE THESE TWO HAVE MANY SIMILARITY-->
				<div class="columns">
					<div class="column is-2 is-offset-2">						
						<aside class="menu">
							<p class="menu-label">
   								Tutorial
 							</p>
 							<ul class="menu-list">
 								<li>
 									<a href="#account">
    									<b>Create and managing account</b>
  									</a>
									<ul>
        								<li><a href="#createacc">Create an account</a></li>
        								<li><a href="#login">Log in and out your account</a></li>
        								<li><a href="#update">Update info</a></li>
      								</ul>
      							</li>
      							<li>
      								<a href="#guide">
    									<b>Guide on surveys</b>
  									</a>
									<ul>
        								<li><a href="#create">Create a survey</a></li>
        								<li><a href="#share">Share a survey</a></li>
        								<li><a href="#takesurvey">Take a survey</a></li>
        								<li><a href="#manage">Managing your surveys</a></li>
        								<li><a href="#analyze">Analyzing a survey</a></li>
      								</ul>
	 							</li>
								<li>
									<a href="#community">
    									<b>Community</b>
  									</a>
								</li>
  							</ul>
							<p class="menu-label">
   								Help
 							</p>
							<ul class="menu-list">
 								<li>
 									<a href="#faq">
    									<b>FAQ</b>
  									</a>
      							</li>
							</ul>
						</aside>
					</div>
					<div class="column is-6 square-box">
						<div id="account">
							<h1 class="title">Create and managing account</h1>
							<div id="createacc">
								<h2 class="has-text-success is-size-5">Create an account</h2>
								<p style="margin: 15px 0">
									To create an account click <b>"Sign up"</b> from menu bar or from default page.<br>
									A sign up form should appear on the screen.<br><br>
									<img src="res/signup.png"></img><br><br>
									Enter your information into each field including: <b>your name, your email, your username and your password.</b>
									Each field must meet these requirement: <br> <br>
									<i>
									- No special characters except "_" in name and username.<br>
									- Username and email must be unique! You can't use one email for different account or an username similar to others.<br>
									- Password must have at least 4 characters and 18 characters max.<br>
									- Username is unchangeable after creating. Make sure to think about it before create an account. <br>
									</i>
								</p>
							</div>
							<div id="login">
								<h2 class="has-text-success is-size-5">Log in and out your account</h2>
								<p style="margin: 15px 0">
									After finish creating your account you can log in to your account by clicking <b>"Log in"</b> from menu bar or the default page. <br>
									A log in form should appear on the screen. <br> <br>
									<img src="res/login.png"></img><br><br>
									Enter your username and password and click the button to login.
									If you want to stay logged in, click <b>"Remember me"</b> to save cookie to your browser. We will only use cookie for this purpose.<br>
									The cookie will expired in 2 months if you stop using our website.<br>
									<a class="title is-size-7 has-text-link has-text-weight-light" href="https://en.wikipedia.org/wiki/HTTP_cookie">What is cookie?</a> <br><br>
									To log out, simply clicking <b>"Log out"</b> at the top right corner of the page.
								</p>
							</div>
							<div id="update">
								<h2 class="has-text-success is-size-5">Update info</h2>
								<p style="margin: 15px 0">
									After logging into your account you can update your account by clicking <b>User setting icon</b> at the top right corner next to Log out button. <br>
									An update form should appear on the screen. <br> <br>
									<img src="res/accountsetting.png"></img><br><br>
									Enter info that you wish to update and click the button to update your info.
									Each field must meet the requirement similar to your sign up form. Blank fields will be skipped.
								</p>
							</div>
						</div>
						<hr>
						<div id="guide">
							<h1 class="title">Guide on surveys</h1>
							<p style="margin: 15px 0">
								You can see example surveys here:<br>
								<a class="has-text-link" href="surveyview.php?id=1"> Example survey </a> <br>
								<a class="has-text-link" href="surveyview.php?id=22"> Example survey extend </a> <br>
								<a class="has-text-link" href="surveyview.php?id=23&key=63L6lyQOlZ"> Example survey: Limited searching example </a> <br>	
							</p>
							<div id="create">
								<h2 class="has-text-success is-size-5">Create a survey</h2>
								<p style="margin: 15px 0">
									To create a new survey click <b>"MAKE A NEW SURVEY"</b> from menu bar.<br>
									A survey create form should appear on the screen.<br><br>
									<img src="res/createsurvey.png"></img><br><br>
									Type in your title, survey's description and start making a form.
									Here you can start creating your survey by using the QUESTION TYPE PANEL.
									To add a question to the form, just simply clicking at the type you like.
									Our tool will generate a question for you to fill in. For custom checkboxs 
									question or multichoice question, after adding the question, you can add new answer to the question
									by clicking <b>"Add an answer"</b> below each question. <br>
									You can undo adding question by clicking undo button. The most recent added question will be removed. <br>
									To limited your survey from be able to search on comunity page, click <b>"Limited survey searching"</b> checkbox. <br>
									Once complete click <b>"Create my survey"</b> to save your form to database. The website will redirect you
									to survey viewing page to see your complete survey.<br><br>
									<img src="res/viewsurvey.png"></img><br><br>
									Here you can review your survey or even take it to test the features out. <br>
								</p>
							</div>
							<div id="share">
								<h2 class="has-text-success is-size-5">Share a survey</h2>
								<p style="margin: 15px 0">
									To share a survey you need a link of that survey. This link can be obtainted by copying the url from
									the survey viewing page or by clicking on <b>"Get link icon"</b> next to the survey on "My Survey" page.<br>
									Once you done, you can share this link to others to collect responses.
								</p>
							</div>
							<div id="takesurvey">
								<h2 class="has-text-success is-size-5">Take a survey</h2>
								<p style="margin: 15px 0">
									A survey is accessable by a link provided by the author.
									The link will send a get request to the server and return you the survey form.<br> <br>
									Here you can start answering questions directly on the website. Once you done, click
									the button to submit your responses. <br>
									You can also help each other out by answering surveys from the community page or search for an user's survey list or a specific survey.<br><br>
									<b>Note: each survey can only be answered once for each person. </b> <br>
									Make sure you think it throughoutly first before hitting Submit.
									Once you submitting, the button will be gone if you comming back to the survey site.
								</p>
							</div>
							<div id="manage">
								<h2 class="has-text-success is-size-5">Managing your surveys</h2>
								<p style="margin: 15px 0">
									It's easy to managing your surveys. <br><br>
									On <b>"Dashboard"</b> you have an overall look on your statistics and your most recent surveys.<br><br>
									<img src="res/dashboard.png"></img><br><br>
									To see all surveys you can click on <b>"MY SURVEYS"</b> to see your survey list.<br><br>
									<img src="res/mysurvey.png"></img><br><br>
									Here you can check on each surveys status, get link for sharing survey or send request for analyzing a survey.
								</p>
							</div>
							<div id="analyze">
								<h2 class="has-text-success is-size-5">Analyzing a survey</h2>
								<p style="margin: 15px 0">
									A request for analyzing a survey can be send by clicking <b>"Analyze icon"</b> 
									next to each survey from the <b>"MY SURVEY"</b> page.
									Here is where you will have all the details look about the survey. <br> <br>
									<b>General Statistics:</b> <br>
									General Statistics including overall information about the survey including: created date and time,
									author ID, survey ID, total questions, total responses and popularity over the time. You can zoom in specific 
									time for details by selecting on the chart or copying the graph by pressing the burger icon. <br> <br>
									<b>Options questions:</b> <br>
									Options questions provide you with the general information of each question as well as the statistics 
									of none textbox questions collected from everyone. Each answers is listed and comes with a bar indicate 
									the total responses choosing it.<br> <br>
									<b>Written questions:</b> <br>
									Written questions listed out all the responses for each question.<br> <br>
									You can also see the original survey by pressing <b>"View this survey"</b>.<br> <br>
									<img src="res/Analyze.png"></img><br><br>
								</p>
							</div>
						</div>
						<div id="community">
							<h1 class="title">Community</h1>
							<p style="margin: 15px 0">
								Community page is accessable by clicking "Community" at the page footer or at the Dashboard page.<br>
								Here you can find some new public surveys or seaching for surveys by username or survey title. By answering these
								surveys you help others just like you on this website.
								If you don't want your survey searchable, you can set it when creating the survey (details is written in "Create a survey").
							</p>
						</div>
						<hr>
						<div id="team", style="margin-top: 15px">
							<h1 class="title" id="faq">FAQ</h1>
							<div id="FAQ">
								<p>
									There're currently no question.<br>
									Send your question to one of our member 
									<a class="title is-size-7 has-text-link has-text-weight-light" href="http://localhost/surveysite/about.php#team">here.</a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--...-->
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	<body>
</html>