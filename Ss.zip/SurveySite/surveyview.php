<?php
	if (!isset($_GET['id'])) {
		header( 'HTTP/1.0 403 Forbidden', TRUE, 403);
		die( header( 'location: /error.php' ));
	}
?>
<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>View a survey</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
		?>
		<!---->
		
		<!--content-->
		<section class="section" id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/writing.png" alt="write img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> SURVEY VIEWING. WE NEED YOUR RESPONSE!</h1>
						<p class="has-text-grey">
							You are currently viewing this survey.<br>
							You can also try and take this survey and click "Submit" to submit your response to the survey. <b> You can only answer this once only </b> so think about it throughoutly before clicking the button.
						</p>
					</div>
				</div>
				
			</div>
		</section>
		
		<section class="section has-background-light" style="padding-left:100px; padding-right:100px">
			<div>
				<form action="recordResponse.php" method="post" id="survey form">
					<?php
						//connect Database
						$surveyForm = array();
						$surveyID = $_GET['id'];
						$userID = $_SESSION['id'];
					?>
					<input type="hidden" name="surveyID" value=<?php echo "$surveyID" ?>>
					<?php
						$surveyForm['id'] = $surveyID;
						$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
						//get survey title and description
						$query = "SELECT surveyID,title,description,isDisable,accessKey,isLimited,tags from `surveys` WHERE surveyID= $surveyID";
						$result = mysqli_query($conn,$query);
						$row = mysqli_fetch_array($result, MYSQLI_NUM);
						if ($row[3] && !$_SESSION['admin']) {
							echo "_No survey found_";
							echo "This survey is either being deleted due to violation or not created yet. <br/>
							Make sure your URL is correct and try again. <br/>
							If you have any question or error want to report, please contact us.";
							exit();
						}
						else {
							$surveyForm['title']=$row[1];
							$surveyForm['description']= $row[2];
							$tags= explode(" ",$row[6]);
							$tagString=$row[6];
						}
						if ($row[5]=='1') {
							if (isset($_GET['key'])) {
								if ($_GET['key']!=$row[4]) {
									echo "_No survey found_";
									echo "This survey is either being deleted due to violation or not created yet. <br/>
									Make sure your URL is correct and try again. <br/>
									If you have any question or error want to report, please contact us.";
									exit();
								}
							}
							else {
								echo "_No survey found_";
								echo "This survey is either being deleted due to violation or not created yet. <br/>
								Make sure your URL is correct and try again. <br/>
								If you have any question or error want to report, please contact us.";
								exit();
							}
						}
						//adding query to get questions and ans.
						$line=0;
						$query="SELECT questionID,surveyID,questionType,question FROM `questions` WHERE surveyID= '$surveyID'";
						$result=mysqli_query($conn,$query);
						while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
							if ($row[2]== 'multichoice' || $row[2]=='checkboxs') {
								$line++;
								$surveyForm["$line"]=$row[2];
								$line++;
								$surveyForm["$line"]=$row[3];
								$qID= $row[0];
								$queryans="SELECT answerID,questionID,surveyID,answerType,answer FROM `answers` WHERE (surveyID = '$surveyID') AND (questionID='$qID')";
								$ans=mysqli_query($conn,$queryans);
								while ($rowans= mysqli_fetch_array($ans, MYSQLI_NUM)) {
									$line++;
									$surveyForm["$line"]=$rowans[3];
									$line++;
									$surveyForm["$line"]=$rowans[4];
								}		
							}
							else {
								$line++;
								$surveyForm["$line"]=$row[2];
								$line++;
								$surveyForm["$line"]=$row[3];
							}
						}
						
					// create survey from database.
					
					include("displaySurvey.php");
					
					// check logged in user.
					
					$query = "SELECT * from `responses` WHERE surveyID= '$surveyID' AND userID='$userID'";
					$result = mysqli_query($conn,$query);
					if ($_SESSION['admin']) {
					?>
						<center style="padding-top:50px">
							<a class="button is-large is-success" href="http://localhost/surveysite/delete.php?id=<?php echo $surveyID;?>" 
							style="border-style: solid; border-color: white; border-radius: 3px;">
								<img src="res/delete.png" style="max-width:25px;max-height:25px; width: auto; height: auto;">
								<p> &nbsp Delete</p>
							</a>
							<a class="button is-large is-success" href="http://localhost/surveysite/restore.php?id=<?php echo $surveyID;?>" 
							style="border-style: solid; border-color: white; border-radius: 3px;">
								<img src="res/undo.png" style="max-width:25px;max-height:25px; width: auto; height: auto;">
								<p> &nbsp Restore</p>
							</a>
						</center>
					<?php
					}
					if ($result->num_rows==0) {
						$query = "SELECT * FROM `surveys` WHERE surveyID='$surveyID'";
						$result = mysqli_query($conn,$query);
						$survey = mysqli_fetch_array($result, MYSQLI_NUM);
						if ($survey[5]==1) {
							?>
							<center class="title">
								THIS SURVEY HAS BEEN DELETED OR NOT CREATED YET.
							</center>
							<?php 
						}
						else {
							if ($survey[9]) {
								?>
								<center class="title">
									SURVEY CLOSED.
								</center>
								<?php
							}
							else {
								?>
								<div>
									<center style="padding-top:50px">
										<button class="button is-large is-success" id="submit button" type="submit" value="submit">
											Submit my response
										</button>
									</center>
								</div>
								<?php
							}
						}
					} else {
					?>
						<p class="center is-size-4">
						You have already answered this survey.
						</p>
					<?php
						}
						mysqli_close($conn);
					?>
				</form>
			</div>
		</section>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="back to top" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	<body>
</html>