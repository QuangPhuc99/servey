<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Create your survey</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
		?>
		<!---->
		
		<!--Content-->
		<!--script-->
		<script src="formmakinggenerator.js">
		</script>
		<!--...-->
		<!--Welcome message-->
		<section class="section" id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/writing.png" alt="write img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> MAKING A FORM</h1>
						<p class="has-text-grey">
							Let's begin the first step of making a survey.<br>
							Enter the title, write the description and let's jump right into making your survey using our QUESTION TYPE PANEL.
						</p>
					</div>
				</div>
				
			</div>
		</section>
		<!--Menu-->
		
		<section class="hero" id="static">
			<div class="hero-body">
				<div class="columns has-background-light">
					<div class="column is-4">
						<nav class="panel is-paddingless has-background-white">
							<p class="panel-heading square-box has-background-light">
								QUESTION TYPE PANEL
							</p>
							<p class="panel-block is-size-6">
								OPTIONS ANSWER
							</p>
							<a class="panel-block" onclick="setMultiChoice()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/multi.png" alt="multichoice icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Custom multiple choices
							</a>
							<a class="panel-block" onclick="setYNQuestion()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/truefalse.png" alt="tf icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Yes/No question
							</a>
							<a class="panel-block" onclick="setSimpleRating()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/happysad.png" alt="tf icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Simple rating
							</a>
							<a class="panel-block" onclick="setSimpleRecommend()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/recommend.png" alt="tf icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Simple recommend rate
							</a>
							<a class="panel-block" onclick="setCheckboxs()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/checkbox.png" alt="checkbox icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Custom checkboxes
							</a>
							<p class="panel-block is-size-6">
								INPUT ANSWER
							</p>
							<a class="panel-block" onclick="setTextbox()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="panel-icon">
									<img src="res/text.png" alt="multichoice icon" style="max-width:20px;max-height:20px; width: auto; height: auto;">
								</span>
								Textbox answer
							</a>
							<a class="panel-block" onclick="setGradeRating()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="fa fa-star">
								</span>
								&nbsp Grade rating
							</a>
							<p class="panel-block is-size-6">
								OTHERS
							</p>
							<a class="panel-block" onclick="setParagraph()">
								&nbsp &nbsp &nbsp  &nbsp &nbsp 
								<span class="far fa-file-word">
								</span>
								&nbsp Paragraph
							</a>
						</nav>
						<p class="subtitle is-size-7">
							Clicking on one of the question type to add it to your survey.
						</p>
					</div>
					<div class="column has-vertical-line">
						<!-- NOTE TO SELF: CHANGE ACTION LATER WHEN DATABASE ADDED -->
						<form action="save.php" method="post" id="survey form">
						<input type="hidden" name="surveyid" value="create">
						<input class="input is-large is-success" name="title" type="text" placeholder="Survey title" maxlength="50" required>
						<input class="input is-small is-success" id="tags" name="tag" type="text" placeholder="Tags. Example: tag1 tag2 tag3" onblur="correctTag()">
						<textarea class="textarea is-success" name="description" placeholder="Survey description" style="resize: none; margin-top:10px;margin-bottom:10px"></textarea>
							<div class="box square-box">
								<div id="question form">
								</div>
								<a class="button is-medium is-success" onclick="undo()">
									Undo &nbsp
									<img src="res/undo.png" alt="undo icon" style="max-width:25px;max-height:25px; width: auto; height: auto;">
								</a>
								<br><br>
								<label class="checkbox center">
									<input type="checkbox" name="limited" value="1">&nbsp Limited survey searching</input>
								</label>
							</div>
							<center>
								<button class="button is-large is-success" id="submit button" type="submit" value="submit">
									Create my survey
								</button>
							</center>
						</form>
					</div>
				</div>
			</div>
		</section>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="back to top" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!--...-->
		<!--Footer-->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	<body>
</html>