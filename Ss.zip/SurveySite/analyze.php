<?php
	if (!isset($_GET['id'])) {
		header( 'HTTP/1.0 403 Forbidden', TRUE, 403);
		die( header( 'location: /error.php' ));
	}
?>
<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<script type="text/javascript" src="canvasjs.min.js"></script>
		<script type="text/javascript" src="moment.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.1/jquery.min.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Analyze</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
		?>
		<!--content-->
		<section class="section" id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/chart.png" alt="Chart img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> ANALYZE YOUR SURVEY. </h1>
						<p class="has-text-grey">
							This is a details look at your surveys statistics.<br>
							Here you can take a closer look at everyone responses on your survey.<br>
							Don't worry! We'll help you with the calculation and represent it in a simple and easy way to understand.
						</p>
					</div>
				</div>
				
			</div>
		</section>
		<!--Statistics-->
		<?php
			//set up connection
			if (session_status() == PHP_SESSION_NONE) {
				session_start();
			}
			$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
			//set id
			$userID=$_SESSION['id'];
			$surveyID=$_GET['id'];
			//check survey
			$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' AND questionType <> 'none'";
			$result= mysqli_query($conn,$query);
			$totalQuestions= $result->num_rows;
			$query = "SELECT * from `responses` WHERE surveyID='$surveyID'";
			$result = mysqli_query($conn,$query);
			$totalResponses= $result->num_rows;
			$query = "SELECT * FROM `surveys` WHERE surveyID='$surveyID'";
			$result = mysqli_query($conn,$query);
			$survey = mysqli_fetch_array($result, MYSQLI_NUM);
			$time = strtotime($survey[4]."-4 days");
			$createdDate = date("Y-m-d", $time);
			$record=0;
			$d=date("Y-m-d");
			$yyyy=date("Y");
			$mm=date("m");
			$dd=date("d");
			$popularity= array();
			$query="SELECT * FROM `responses` WHERE surveyID='$surveyID' AND DATE(date) = '$d'";
			$pop= mysqli_query($conn,$query);
			$popularity[$record]=$pop->num_rows;
			while ($d != $createdDate) {
				$record++;
				$d=date("Y-m-d",strtotime("-$record day"));
				$query="SELECT * FROM `responses` WHERE surveyID='$surveyID' AND DATE(date) = '$d'";
				$pop= mysqli_query($conn,$query);
				$popularity[$record]=$pop->num_rows;
			}
		?>
		<!---->
		<!--Create chart-->
		<script type="text/javascript">
		//popularityChart
			var dateOffset = 24*60*60*1000;
			window.onload = function() {
				var chart = new CanvasJS.Chart("popularityrate",
					{
						theme: "light2",
						exportEnabled: true,
						animationEnabled: true,
						zoomEnabled: true,
						title:{
							text: "Responses rate"
						},
						axisX:{
							title: "Date",
							interval: 1
						},
						axisY: {
							interval: 1
						},
						legend:{
							verticalAlign: "top",
							fontSize: 16,
							dockInsidePlotArea: true
						},
						data: data
					});
				chart.render();
			}
			var limit = <?php echo "$record" ;?>;
			var y = 0;
			var data = [];
			var dataSeries = { type: "line" , showInLegend: true, name: "response"};
			var dataPoints = [];
			var popularity = <?php echo json_encode($popularity); ?>;
			for (var i = 0; i <= limit; i += 1) {
				var d = new Date(<?php echo "$yyyy" ;?>,<?php echo "$mm" ;?>,<?php echo "$dd" ;?>);
				d.setTime(d.getTime() - dateOffset*i);
				y = popularity[i];
				dataPoints.push({
					x: d,
					y: y
				});
			}
			dataSeries.dataPoints = dataPoints;
			data.push(dataSeries);
		</script>
		<section class="section has-background-light" style="padding-left:100px; padding-right:100px">
			<?php
				if ($survey[3]!=$_SESSION['id'] || $survey[5]==1) {
					?>
					<center class="title">
						YOU CAN'T SEE THIS SURVEY'S STATISTICS. <br>
						THIS SURVEY IS EITHER HAS BEEN TAKEN DOWN BY OUR ADMIN OR THIS IS AN UNAUTHORIZED ACCOUNT FOR THIS SURVEY. AUTHOR ONLY.
					</center>
					<?php
					exit();
				}
			?>
			<!--Overview on survey statistics-->
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<h1 class="title is-size-3">
						General Statistics
					</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<table class="table is-bordered is-fullwidth">
						<tbody>
							<tr>
								<td style="width: 45vw">
									<h1 class="has-text-black is-size-5">
										<?php echo "$survey[1]"; ?>
									</h1>
									<p class="has-text-grey has-text-weight-light is-size-7">
										Created: <?php echo "$survey[4]"; ?> |
										Author ID: <?php echo "$survey[3]"; ?> | 
										Survey ID: <?php echo "$survey[0]"; ?>
									</p>
									<p class="has-text-grey has-text-weight-light is-size-7 tablet">
										Total questions: <?php echo "$totalQuestions"; ?> | Total responses: <?php echo "$totalResponses"; ?>
									</p>
								</td>
								<td class="is-marginless desktop">
									<h1 class="has-text-grey has-text-weight-light is-size-5">
										Total questions
									</h1>
									<p class="has-text-grey is-size-5">
										<?php echo "$totalQuestions"; ?>
									</p>
								</td>
								<td class="is-marginless desktop">
									<h1 class="has-text-grey has-text-weight-light is-size-5">
										Total responses
									</h1>
									<p class="has-text-grey is-size-5">
										<?php echo "$totalResponses"; ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="has-text-weight-light"> 
						Current server date: <?php echo "$dd/$mm/$yyyy"?> 
					</div>
					<div id="popularityrate" style="border: 1px grey solid; height: 300px; width: 100%;"></div>
				</div>
			</div>
			<!--Details on option questions-->
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<h1 class="title is-size-3">
						Options questions.
					</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<?php
						$para=0;
						$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' AND questionType<>'textbox' ORDER BY `questionID` ASC";
						$result= mysqli_query($conn,$query);
						//print all questions.
						while ($q= mysqli_fetch_array($result, MYSQLI_NUM)) {
							$currentQuestion=$q[0];
							if ($q[2] == 'none') {
								$para++;
								continue;
							}
							$query="SELECT * FROM `answers` WHERE `questionID`='$currentQuestion' AND `surveyID`='$surveyID' ORDER BY `answerID` ASC";
							$answers= mysqli_query($conn,$query);
							$totalAns= $answers->num_rows;
							?>
								<h1 class="box square-box has-background-grey has-text-white spaced-out-wide">
									<p class="is-size-6">
										<?php
											$qNumTemp = $q[0] - $para;
											echo "Question $qNumTemp: $q[3]"; 
										?>
									</p>
									<?php
									if ($q[2]=='yn') {
										?>
											<p class="subtitle has-text-white is-size-7" style="text-transform: uppercase;">
												<?php echo "Question type: Yes No Question"?>
											</p>
										<?php
									}
									else {
										?>
											<p class="subtitle has-text-white is-size-7" style="text-transform: uppercase;">
												<?php echo "Question type: $q[2]"?>
											</p>
										<?php
									}
									?>
								</h1>
							<table class="table is-fullwidth is-striped">
							<?php
							if ($q[2]=='rating') {
								$currentQuestion=$q[0];
								$query="SELECT * FROM `text_responses` tr INNER JOIN `responses` r ON tr.responseID=r.responseID WHERE r.surveyID='$surveyID' AND tr.questionID='$currentQuestion'";
								$rResponses = mysqli_query($conn,$query);
								$totalRating=0;
								$totalR=0;
								$badRating=0;
								$goodRating=0;
								while ($rres = mysqli_fetch_array($rResponses, MYSQLI_NUM)) {
										if (!empty($rres[2])){
											$totalR++;
											$totalRating += (int) $rres[2];
											if ($rres[2]>5) $goodRating++;
											else $badRating++;
										}
									}
								if ($totalR>0) {
									$totalRating /= $totalR;
									$totalRating = round($totalRating);
								}
								?>
									<h1 class="square-box has-text-grey has-text-weight-light is-size-6">
										<?php
											echo "Average rating: $totalRating / 10"; 
											for ($star=0; $star<$totalRating;$star++) {
												?>															
													<span class="fa fa-star starchecked">
													</span>
												<?php
											}
											for ($star=0; $star<10-$totalRating;$star++) {
												?>															
													<span class="fa fa-star">
													</span>
												<?php
											}
											?>
											<br>
											<p>
												Bad (5-<span class="fa fa-star starchecked"></span> or lower) rating: <?php echo"$badRating"  ?> <br>
												Good (6-<span class="fa fa-star starchecked"></span> or lower) <span class="fa fa-star starchecked"></span> rating: <?php echo"$goodRating" ?> <br>
											</p>
									</h1>
								<?php
							}
							//print all answers.
							$color= array ('','is-success','is-danger','is-primary','is-link','is-info','is-warning','is-dark');
							while ($opt= mysqli_fetch_array($answers, MYSQLI_NUM)) {
								$answerID=$opt[0];
								$colorNum= $answerID % 6;
								$query="SELECT * FROM `option_responses` opr 
								INNER JOIN `responses` r 
								ON r.responseID = opr.responseID 
								WHERE r.`surveyID`='$surveyID' 
								AND opr.`questionID`='$currentQuestion' 
								AND opr.`answerID`='$answerID'";
								$stat=mysqli_query($conn,$query);
								$totalR=$stat->num_rows;
								?>
									<tr>
										<td class="has-text-black is-size-6 spaced-out-wide" title="<?php echo "$opt[4]"?>" style="width: 15vw">
											<?php 
												if (strlen($opt[4])>30) {
													$sort = substr($opt[4],0,30);
													echo "$sort...";
													?>
														<p class="has-text-grey has-text-weight-light is-size-7">
															Hover to see more.
														</p>
													<?php
												}
												else {
													echo "$opt[4]";
												}
											?>
										</td>
										<td>
											<progress class="progress <?php echo $color[$colorNum];?>" 
											value="<?php echo "$totalR";?>" 
											max="<?php echo "$totalResponses"?>"></progress>
											<?php
												if ($totalResponses!=0)	$percentage = round($totalR * 100 / $totalResponses);
												else $percentage= "NaN";
												echo "$totalR / $totalResponses | $percentage %";
											?>
										</td>
									</tr>
								<?php
							}
							?>
							</table>
							<?php
						}
					?>
				</div>
			</div>
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<h1 class="title is-size-3">
						Written questions.
					</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column is-10 is-offset-1">
					<?php
						$para=0;
						$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' AND (questionType='textbox' OR questionType = 'none') ORDER BY `questionID` ASC";
						$result= mysqli_query($conn,$query);
						while ($q= mysqli_fetch_array($result, MYSQLI_NUM)) {
							if ($q[2] == 'none') {
								$para++;
								continue;
							}
							$qNumTemp = $q[0] - $para;
							?>
								<h1 class="box square-box has-background-info has-text-white is-size-6 spaced-out-wide">
									<?php echo "Question $qNumTemp: $q[3]"; ?>
								</h1>
							<?php
							$currentQuestion=$q[0];
							$query="SELECT * FROM `text_responses` tr INNER JOIN `responses` r ON tr.responseID=r.responseID WHERE r.surveyID='$surveyID' AND tr.questionID='$currentQuestion'";
							$textResponses = mysqli_query($conn,$query);
							$resNo=0;
							while ($tres = mysqli_fetch_array($textResponses, MYSQLI_NUM)) {
								$resNo++;
								if (empty($tres[2])){
									?>
									<h1 class="square-box has-text-grey has-text-weight-light is-size-6">
										<?php
											echo "Response $resNo: $tres[2]_User skip this question_"; 
										?>
									</h1>
									<?php
								}
								else {
								?>
									<h1 class="square-box has-text-black is-size-6">
										<?php
											echo "Response $resNo: $tres[2]"; 
										?>
									</h1>
								<?php
								}
							}
						}
					?>
				</div>
			</div>
			<center>
				<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/surveyview.php?id=<?php echo "$survey[0]&key=$survey[7]" ;?>" style="border-style: solid; border-color: white; border-radius: 3px;">
					<img src="res/eyewhite.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					<p> &nbsp View this survey</p>
				</a>
			</center>
		</section>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="back to top" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--include footer here-->
		<?php 
			mysqli_close($conn);
			include("footer.php");
		?>
		<!---->
	<body>
</html>