<?php
	session_start();
    if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
        header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
        die( header( 'location: /error.php' ) );
    }
	$qNumber=0;
	$id;
	$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
	$query = "SELECT * FROM `responses`";
	$result=mysqli_query($conn,$query);
	$id=$result->num_rows;
	$id++;
	$userID = $_SESSION['id'];
	$surveyID = $_POST['surveyID'];
	$date = date("Y-m-d h:i:s");
	$query = "INSERT INTO `responses` (responseID,userID,surveyID,date) VALUES ('$id','$userID','$surveyID','$date')";
	$result=mysqli_query($conn,$query);
	foreach ($_POST as $param_name) {
		echo "$qNumber <br/>";
		if (is_array($param_name) && $qNumber>0) {
			foreach ($param_name as $i => $value) {
				echo "$i = $value <br>";
				if ($i>0) {
					$value= mysqli_real_escape_string($conn,$value);
					$query = "INSERT INTO `option_responses` (responseID,questionID,answerID) VALUES ('$id','$qNumber','$value')";
					$result=mysqli_query($conn,$query);
				}
			}
			echo "------------------ <br>";
		}
		else if ($qNumber>0){
			$param_name= mysqli_real_escape_string($conn,$param_name);
			$query = "INSERT INTO `text_responses` (responseID,questionID,answer) VALUES ('$id','$qNumber','$param_name')";
			$result=mysqli_query($conn,$query);
			echo "Value: $param_name <br>";
			echo "------------------<br>";
		}
		$qNumber++;
	}
	mysqli_close($conn);
	header('location: dashboard.php');
?>