<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Sign up</title>
	</head>
	<body>
		<!--Header-->
		<?php
			include('redirect1.php');
			include("header.php");
		?>
		<!---->
		
		<!--script-->
		<?php
			$error='';
			$special = '/[\'\/~`\!@#\$%\^&\*\(\)\-\+=\{\}\[\]\|;:"\<\>,\.\?\\\]/';
			if (isset($_POST['signup']) && !empty($_POST['username']) && !empty($_POST['password'])) {
				//connect...
				$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
				//values
				$username=$_POST['username'];
				$username= mysqli_real_escape_string($conn,$username);
				$password=$_POST['password'];
				$password= mysqli_real_escape_string($conn,$password);
				$email=$_POST['email'];
				$email= mysqli_real_escape_string($conn,$email);
				$name=$_POST['name'];
				$name= mysqli_real_escape_string($conn,$name);
				$valid=true;
				$query="SELECT userName FROM `users`";
				$result=mysqli_query($conn,$query);
				$userID= $result->num_rows;
				$userID++;
				$query="SELECT userName FROM `users` WHERE userName='$username';";
				$result=mysqli_query($conn,$query);
				
				//validate
				if ($result->num_rows > 0) {
					$error = $error.'Username existed. Please try something else'."<br/>";
					$valid=false;
				}
				$query="SELECT email FROM `users` WHERE email='$email';";
				$result=mysqli_query($conn,$query);
				if ($result->num_rows > 0){
					$error = $error.'Email existed. You have already signed up'."<br/>";
					$valid=false;
				}
				if (strlen ($_POST['password'])<4 || strlen ($_POST['password'])>18 || preg_match($special,$_POST['username']) ){
					$error = $error.'Password must have 4-18 characters'."<br/>";
					$valid=false;
				}
				if (preg_match($special,$username) || strpos($username, ' ')!==false || preg_match($special,$name) ){
					$error = $error.'Name and Username can\'t have special characters but "_" '."<br/>";
					$valid=false;
				}
				//add user
				if ($valid==true){
					$error='';
					//add new user to database
					$q="INSERT INTO `users` (`userID`,`userName`, `password`, `name`, `email`, `isAdmin`) VALUES ('$userID', '$username', '$password', '$name', '$email', '0')";
					$r=mysqli_query($conn,$q);
					header('location: login.php');
				}
			}
		?>
		<!---->
		
		<!--content-->
		<section class="section" id="content" style="min-height: 95vh;">
			<div class="container">
				<div class="columns">
					<div class="column is-1 desktop">
					</div>
					<!--Sign up box-->
					<div class="column">
						<div class="box square-box">
							<article class="media center">
								<div class="media-content">
									<div class="title is-horizontal center">
										<center>
											<h1 class="title center">
												Sign up for an account<br>
											</h1>
										</center>
									</div>
									<hr>
									<form class ="notification" role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
										<div class="field is-horizontal">
											<div class="field-label is-normal">
												<label class="label" style="width: 100px"> Name:</label>
											</div>
											<div class="field-body">
												<div class="field">
													<p class="control">
														<input class="input is-success is-capitalized" name="name" type="text" placeholder="Example: Mary Jane" required autofocus>
													</p>
												</div>
											</div>
										</div>
										<div class="field is-horizontal">
											<div class="field-label is-normal">
												<label class="label" style="width: 100px"> Email:</label>
											</div>
											<div class="field-body">
												<div class="field">
													<p class="control">
														<input class="input is-success" name="email" type="email" placeholder="example@abc.com" required autofocus>
													</p>
												</div>
											</div>
										</div>
										<div class="field is-horizontal">
											<div class="field-label is-normal">
												<label class="label" style="width: 100px"> Username:</label>
											</div>
											<div class="field-body">
												<div class="field">
													<p class="control">
														<input class="input is-success" name="username" type="text" placeholder="Username" required autofocus>
													</p>
												</div>
											</div>
										</div>
										<div class="field is-horizontal">
											<div class="field-label is-normal">
												<label class="label" style="width: 100px"> Password:</label>
											</div>
											<div class="field-body">
												<div class="field">
													<p class="control">
														<input class="input is-success" name="password" type="password" placeholder="Password"  maxlength="18" required>
													</p>
												</div>
											</div>
										</div>
										<div class="field is-horizontal center">
											<center>
												<p class="has-text-danger">	
												</p>
											</center>
										</div>
										<div class="field is-horizontal center">
											<center>
												<p class="has-text-danger">
												<!--Error goes here--><?php echo $error ?><br>
												</p>
											</center>
										</div>
										<center>
											<button class="button is-success center" type="submit" name="signup" value="sign up">
													<b>&nbsp &nbsp &nbsp Sign up &nbsp &nbsp &nbsp </b>
											</button>
										</center>
										<p class="is-size-7">
											Note: Username is unchangeable.
										</p>
									</form>
								</div>
							</article>
						</div>
					</div>
					<!--Some decoration-->
					<div class="column desktop">
						<div class="box square-box">
							<div class="spaced-out-medium">
								<center>
									<h1 class="title has-text-weight-light">Start signing up and <br> make your survey</h1>
								</center>
							</div>
							<hr>
							<p class="subtitle has-text-weight-light">
								<img src="res/check.png" alt="bullet" style="max-width:15px;max-height:15px; width: auto; height: auto;">
								Creating an easy and effective survey. <br> <br>
								<img src="res/check.png" alt="bullet" style="max-width:15px;max-height:15px; width: auto; height: auto;">
								Sharing your survey and get responses. <br> <br>
								<img src="res/check.png" alt="bullet" style="max-width:15px;max-height:15px; width: auto; height: auto;">
								Help analyze the results.
							<p>
							<img src="res/signup_sign.png" alt="sign up sign" style="width: 100%; height: auto;">
						</div>
					</div>
					<div class="column is-1 desktop">
					</div>
					<!--...-->
				</div>
			</div>
		</section>
		<!--...-->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	</body>
</html>