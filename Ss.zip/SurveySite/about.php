<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>About</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
		?>
		<!---->
		
		<!--content-->
		<!--Title goes here-->
		<section class="section " id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/about.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> ABOUT SURVEY SITE. </h1>
						<p class="has-text-grey">
							Hello and welcome to About page. <br>
							This is a brief introduction about our survey site and the development team. <br>
							Want to know more? Why don't you check out <a class="has-text-black" href="faq.php">Help.</a>
						</p>
					</div>
				</div>
			</div>
		</section>
		<!--Content goes here-->
		<section class="hero has-background-light" id="static">
			<div class="hero-body">
				<!--content about survey site (!IMPORTANT: SITE INFO NEEDS TO ADD FIRST)-->
				<!--About site must include: site purpose, BRIEF talk about tools and features. (2 paragraphs)-->
				<!--content about developer (ADD AFTER SURVEY SITE)-->
				<!--Including: name, contact info, keep this brief. Check link for ref: https://www.surveymonkey.com/mp/aboutus/leadership/ -->
				<!--NOTE: Add id number for easier references"-->
				<!--NOTE: Add a side menu for easier find in this document. Check link for ref: https://bulma.io/documentation/components/menu/	-->
				<!--NOTE: Tab in AT LEAST 1-3/12 screen size on both left and right-->
				<!--NOTE: Less is more! Make it simple yet easy to read-->
			<div class="columns">
					<div class="column is-2 is-offset-2">
						<aside class="menu desktop">
							<h1 class="menu-label">
   								 About
 							</h1>
 							<ul class="menu-list">
 								<li>
 									<a href="#aboutss">
    									<b>About Survey Site</b>
  									</a>
  									<ul>
        								<li><a href="#whatissurveysite">What is Survey Site?</a></li>
        								<li><a href="#features">Features</a></li>
      								</ul>
      							</li>
      							<li>
      								<a href="#team">
    									<b>Development team</b>
  									</a>
	 							</li>
  							</ul>
						</aside>
					</div>
					<div class="column is-6 square-box">
						<div id="about-us">
							<h1 class="title" id="aboutss">About Survey Site</h1>
							<div id="purpose">
								<h2 class="has-text-success is-size-5" id="whatissurveysite">What is Survey Site?</h2>
								<p style="margin: 15px 0">
									Survey site is an online survey creating tool. Here you can create your own survey using our pre-coded question forms.
									We using Bulma framework for a desktop/moblile friendly website.
									You'll be surprise what you can do with what we got for you. Not only that, after creating your survey,
									you can share, collect responses and with the help of our website, everything will be analyzed and show it to you. However, the website
									is currently under development, we're still continue to add more features hoping to give you a better experience creating and
									managing your surveys. <br><br>
									If you have any question, please contact us using our info below or clicking on "Mail us" at the foot of this website.<br> <br>
									<b>Thank you for using our Survey Site.</b>
								</p>
							</div>
							<div id="features">
								<h2 class="has-text-success is-size-5" id="features">Website Features</h2>
								<p style="margin: 15px 0">
									On this website, we always try adding new features to give you a better experience. Here is an overall look on some of our features:<br><br>
									- Auto adjusted layout to fit with mobile, tablet, PC and laptop. <br>
									- Work with multiple browsers. <br>
									- Multiple pre-coded question types. <br>
									- Auto create shareable survey form from your input. <br>
									- A managing board with all your surveys listed. <br>
									- Analyzing tool helps you keep track of every aspect of your survey including overall info, popularity and responses. <br>
									- A community page with ability to search for surveys by username or survey's title. <br>
								</p>
							</div>
						</div>
						<hr>
						<div id="team", style="margin-top: 15px">
							<h1 class="title">Development team</h1>
							<div id="name">
								<p >	
									<b>Tran Dao Manh</b> <br><br>
									Team leader/ Back-end developer/ Front-end developer/ Database design<br>
									Email: trandaomanh1911@gmail.com<br>
									Phone: 0868918546<br><br>
								</p>
								<p>
									<b>Truong Quang Phuc</b><br><br>
									Tester/ Front-end developer/ Back-end developer<br>
									Email: 17020963@vnu.edu.vn<br><br>
								</p>
								<p>
									<b>Phan Van Phuoc</b><br><br>
									Tester/ Database design/ Back-end developer<br>
									Email: 14020602@vnu.edu.vn<br><br>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--...-->
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<!---->
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	<body>
</html>