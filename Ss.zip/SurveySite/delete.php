<?php
	session_start();
	if ($_SESSION['admin']) {
		$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
		$surveyID = $_GET['id'];
		$query = "UPDATE `surveys` SET `isDisable`='1' WHERE surveyID= $surveyID";
		$result = mysqli_query($conn,$query);
	}
	header('location: viewAll.php');
?>