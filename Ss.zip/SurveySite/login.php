<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>Login </title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("redirect1.php");
			include("header.php");
		?>
		<!---->
		
		<!--script-->
		<?php 
			// Checking if user has already logged in. If true: redirect to dashboard.
			if (isset($_SESSION['username'])) header('location: dashboard.php');
			$error='';
			// Checking input. If valid: set session and logged in.
			if (isset($_POST['login']) && !empty($_POST['username']) && !empty($_POST['password'])) {
				//connect...
				$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
				//values
				$username=$_POST['username'];
				$username= mysqli_real_escape_string($conn,$username);
				$password=$_POST['password'];
				$password= mysqli_real_escape_string($conn,$password);
				$query="SELECT userID, username, password, name, isAdmin, isBanned FROM `users` WHERE userName='$username' AND password='$password'";
				$result=mysqli_query($conn,$query);
				if ($result->num_rows > 0) {
					$_SESSION['valid'] = true;
					$user = mysqli_fetch_array($result, MYSQLI_NUM);
					if (!$user[5]) {
						$_SESSION['id'] = $user[0];
						$_SESSION['username'] = $_POST['username'];
						$_SESSION['name'] = $user[3];
						$_SESSION['admin'] = $user[4];
						$_SESSION['rememberme'] = $_POST['rememberme'];
						header('location: access.php');
					}
					else {
						$error = "This user is banned.";
					}
				}
				else {
					$error = 'Incorrect username or password.';
				}
				mysqli_close($conn);
			}
		?>
		<!---->
		
		<!--content-->
		<section class="section" id="content" style="min-height: 95vh;">
			<div class="container">
				<div class="columns">
					<!--Log in box-->
					<div class="column is-half is-offset-one-quarter">
						<article class="media center">
							<div class="media-content">
								<div class="title is-horizontal center">
									<center>
										<h1 class="title center">
											Log in to your account<br>
										</h1>
									</center>
								</div>
								<hr>
								<form class ="notification" role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
									<div class="field is-horizontal">
										<p> <br> </p>
									</div>
									<div class="field is-horizontal">
										<div class="field-label is-normal">
											<label class="label" style="width: 100px"> Username:</label>
										</div>
										<div class="field-body">
											<div class="field">
												<p class="control">
													<input class="input is-success" name="username" type="text" placeholder="Username" required autofocus>
												</p>
											</div>
										</div>
									</div>
									<div class="field is-horizontal">
										<div class="field-label is-normal">
											<label class="label" style="width: 100px"> Password:</label>
										</div>
										<div class="field-body">
											<div class="field">
												<p class="control">
													<p class="control has-icons-right">
														<input class="input" id="password" name="password" type="password" placeholder="Password" required>
													</p>
												</p>
											</div>
										</div>
									</div>
									<div class="field is-horizontal">
										<div class="field-label is-normal">
											<label class="checkbox">
												<input type="checkbox" name="rememberme">
													Remember me
											</label>
										</div>
									</div>
									<div class="field is-horizontal center">
										<center>
											<p class="has-text-danger">
											<!--Error goes here--><?php echo $error ?><br>
											</p>
										</center>
									</div>
									<center>
									<button class="button is-success center" type="submit" name="login">
											<b>&nbsp &nbsp &nbsp LOG IN &nbsp &nbsp &nbsp </b>
									</button>
									</center>
								</form>
							</div>
						</article>
						<div>
							<center> Don't have an account? </center>
							<a href="signup.php">
								<img src="res/signup_sign.png" alt="sign up sign" style="width: 100%; height: auto;">
							</a>
						</div>
					</div>
					<!--...-->
				</div>
			</div>
		</section>
		<!--...-->
		
		<!--include footer here-->
		<?php 
			include("footer.php");
		?>
		<!---->
	</body>
</html>