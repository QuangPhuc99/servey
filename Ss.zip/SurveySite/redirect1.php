<?php
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['valid'] = true;
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['password'] = $_COOKIE['password'];
		$_SESSION['rememberme'] = "remember";
		setcookie("username", $_SESSION['username'], time()+86400*60, "/","", 0);
	}
	if (isset($_SESSION['username'])) 
	{
		header('location: dashboard.php');
	}
	else {
		session_destroy();
	}
?>