<?php
	function generateRandomString() {
		$length = 10;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	session_start();
	//prevent accessing this file from http get request.
	if ($_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
		header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
		die( header( 'location: /error.php' ) );
	}
	
	//Save data to database;
	//generate variables;
	$i=0;
	$akey="";
	$lineType="";
	$questionNumber=0;
	$ansNumber=0;
	//connect to Database and create surveyID;
	$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
	//count surveys and generate an id for survey;
	$query="select * from `surveys`";
	$result=mysqli_query($conn,$query);
	$id=$result->num_rows;
	$id++;
	//create new survey in Database with setted title and description;
	$title = $_POST['title'];
	$title = mysqli_real_escape_string($conn,$title);
	$description = $_POST['description'];
	$description = mysqli_real_escape_string($conn,$description);
	$tag = $_POST['tag'];
	$tag = mysqli_real_escape_string($conn,$tag);
	$userID = $_SESSION['id'];
	//insert new survey to database;
	if (isset($_POST['limited'])) {
		$key= generateRandomString();
		$akey=$key;
		$key = mysqli_real_escape_string($conn,$key);
		$query="INSERT INTO `surveys` (surveyID,title,description,userID,isLimited,accessKey,tags) 
			VALUES ('$id' , '$title' , '$description' , '$userID','1','$key','$tag')";
	}
	else {
		$query="INSERT INTO `surveys` (surveyID,title,description,userID,tags) 
			VALUES ('$id' , '$title' , '$description' , '$userID','$tag')";
	}
	$result=mysqli_query($conn,$query); //run query;
	//save form to Database.
	foreach ($_POST as $param_name => $param_val) {
		if ($i>3) {
			if ($i % 2== 0) {
				$lineType=$param_val; //get Line Type;
				$lineType = mysqli_real_escape_string($conn,$lineType);
			}
			else {
				if (substr($lineType,0,3) != "ans") {
					$questionNumber++;
					$ansNumber=0;
					$param_val = mysqli_real_escape_string($conn,$param_val);
					$query="INSERT INTO `questions` (questionID,surveyID,questionType,question) VALUES ('$questionNumber', '$id', '$lineType', '$param_val')";
					$result=mysqli_query($conn,$query); //run query;
					if ($lineType == "yn") {
						$query="INSERT INTO `answers` (answerID, questionID, surveyID,answerType, answer) VALUES ('1','$questionNumber','$id', 'ansradio', 'Yes')";
						$result=mysqli_query($conn,$query);
						$query="INSERT INTO `answers` (answerID, questionID, surveyID, answerType, answer) VALUES ('2','$questionNumber','$id','ansradio', 'No')";
						$result=mysqli_query($conn,$query);
					}
				}
				else {
					$ansNumber++;
					//insert row with (ansNumber+questionNumber+surveyID) =>PKey, type, value;
					$param_val = mysqli_real_escape_string($conn,$param_val);
					$query="INSERT INTO `answers` (answerID, questionID, surveyID, answerType, answer) VALUES ('$ansNumber','$questionNumber','$id','$lineType', '$param_val')";	
					$result=mysqli_query($conn,$query);
				}
			}
		}
		$i++;
	}
	mysqli_close($conn);
	//redirect to Survey view site;
	header("location: surveyview.php?id=$id&key=$akey"); 
?>