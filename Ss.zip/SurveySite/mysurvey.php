<!DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Survey website">
		<meta name="author" content="Group 12">
		<link rel="stylesheet" type = "text/css" href = "bulma.css" media = " all"/>
		<link rel="stylesheet" type = "text/css" href = "style.css" media = " all"/>
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.1/jquery.min.js"></script>
		<link rel="icon" href="res/logogreen.png"> <!--insert logo link here-->
		<title>My Survey</title>
	</head>
	<body>
		<!--Header-->
		<?php 
			include("header.php");
			if (!isset($_SESSION['username'])) 
			{
				header('location: default.php');
			}
			$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
			$userID = $_SESSION['id'];
			$query="SELECT * FROM `surveys` WHERE userID='$userID' AND isDisable=0";
			$result= mysqli_query($conn,$query);
			$totalSurvey= $result->num_rows;
		?>
		<!---->
		
		<!--Content-->
		<!--Welcome message-->
		<section class="section " id="welcome">
			<div class="container">
				<div class="media">
					<div class="media-left">
						<img src="res/lib.png" alt="hello img" style="max-width:150px;max-height:150px; width: auto; height: auto;">
					</div>
					<div class="media-content">
						<h1 class="title is-uppercase has-text-weight-light"> Your surveys. </h1>
						<p class="has-text-grey">
							This is your surveys list.<br>
							Here you can managing all your surveys. See basic informations and choose what to do.
						</p>
					</div>
				</div>
			</div>
		</section>
		<!--Dashboard-->
		<div class="columns has-background-light">
			<div class="column is-8 is-offset-2">
				<div class="is-marginless">
					<h1 class="is-size-3 has-text-weight-light spaced-out"> All surveys </h1>
					<p class="is-size-6 has-text-weight-light spaced-out"> 
						Total surveys: <?php echo "$totalSurvey" ?>
					</p>
					<table class="table is-hoverable is-fullwidth is-striped" style="border: 1px solid;">
						<thead>
							<tr>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Title</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Created</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Questions</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Responses</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Analyze</th>
								<th class="has-background-dark has-text-white" style="border-right: solid;">Close/Open</th>
								<th class="has-background-dark has-text-white">Get link</th>
							</tr>
						</thead>
						<tbody>
							<!--script-->
							<script>
								function copyLink(val) {
									var link = document.createElement("input");
									link.value = "localhost/surveysite/surveyview.php?id=" + val;
									document.body.appendChild(link);
									link.focus();
									link.select();
									document.execCommand("copy");
									document.body.removeChild(link);
								}
								function alter(sid) {
									var xhttp;
									if (sid == 0) {
										return;
									}
									xhttp = new XMLHttpRequest();
									xhttp.onreadystatechange = function() {
										if (this.readyState == 4 && this.status == 200) {
											document.getElementById("closeopen"+sid).innerHTML = this.responseText;
										}
									};
									xhttp.open("GET", "managingboard.php?sID="+sid, true);
									xhttp.send();
								}
							</script>
							<!--...-->
							<?php
								$query="SELECT * FROM `surveys` WHERE userID='$userID' AND isDisable=0 ORDER BY date DESC;";
								$result= mysqli_query($conn,$query);
								if ($result->num_rows==0) {
							?>
									<tr>
										<td>
											_No survey created_
										</td>
										<td>
											____-__-__ __:__:__
										</td>
										<td>
											__
										</td>
										<td>
											___
										</td>
										<td>
											
										</td>
										<td>
											
										</td>
										<td>
											
										</td>
									</tr>
							<?php
								} else
								{
									for ($i=0;$i < $totalSurvey; $i++) {
										$survey= mysqli_fetch_array($result, MYSQLI_NUM);
										$query="SELECT * FROM `questions` WHERE surveyID='$survey[0]' AND questionType <> 'none';";
										$q= mysqli_query($conn,$query);
										$totalQuestions= $q->num_rows;
										$query="SELECT * FROM `responses` WHERE surveyID='$survey[0]';";
										$r= mysqli_query($conn,$query);
										$totalRes = $r->num_rows;
										$getVal="$survey[0]";
										if ($survey[6] == 1) {
											$getVal= "$survey[0]&key=$survey[7]";
										}
										?>
										<tr>
											<td>
												<?php echo "$survey[1]" ;?>
											</td>
											<td>
												<?php echo "$survey[4]" ;?>
											</td>
											<td>
												<?php echo "$totalQuestions" ;?>
											</td>
											<td>
												<?php echo "$totalRes" ;?>
											</td>
											<td>
												<a class="button" href="http://localhost/surveysite/analyze.php?id=<?php echo "$survey[0]" ?>">
													<img src="res/chart.png" alt="analyze" style="max-width:15px;max-height:15px; width: auto; height: auto;">
												</a>
											</td>
											<td>
												<a class="button" onclick="alter(<?php echo "$survey[0]" ?>)" id=<?php echo "closeopen$survey[0]" ?>	>															
													<?php 
													if (!$survey[9]) {
													?>
														<i class='fas'>&#xf023;</i>
													<?php
													}
													else { ?>	
														<i class='fas'>&#xf3c1;</i>
													<?php
													}
													?>
												</a>
											</td>
											<td>
												<a class="button" onclick="copyLink('<?php echo "$getVal";?>')">
													<img src="res/link.png" alt="getlink" style="max-width:15px;max-height:15px; width: auto; height: auto;">
												</a>
											</td>
										</tr>
							<?php
									}
								}
							?>
						</tbody>
					</table>
					<a class="button has-text-weight-bold is-success i" href="http://localhost/surveysite/createsurvey.php" style="border-style: solid; border-color: white; border-radius: 3px;">
						<img src="res/add.png" style="max-width:15px;max-height:15px; width: auto; height: auto;">
						<p> &nbsp Make a new survey</p>
					</a>
				</div>
			</div>
		</div>
		<a class="button is-medium corner3" href="#header">
			<img src="res/back-to-top.png" alt="logo" style="max-width:25px;max-height:25px; width: auto; height: auto;">
		</a>
		<div class="columns has-background-light">
			<div class="column is-4 is-offset-2">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						About
						<img src="res/helpblack.png" alt="survey icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Learn more about surveys management tools<a class="title is-size-7 has-text-link has-text-weight-light" href="about.php"> here </a><br> 
					</p>
				</div>
			</div>
			<div class="column is-4">
				<div class="box square-box"  style="margin-bottom: 20px;">
					<h1 class="has-text-grey has-text-weight-light is-size-5">
						FAQ
						<img src="res/helpblack.png" alt="ans icon" style="max-width:15px;max-height:15px; width: auto; height: auto;">
					</h1>
					<p class="has-text-grey is-size-7">
						<br>Something trouble you about our system? Check it <a class="title is-size-7 has-text-link has-text-weight-light" href="faq.php">here</a><br> 
					</p>
				</div>
			</div>
		</div>
		<!---->
		<!--Footer-->
		<!--include footer here-->
		<?php
			mysqli_close($conn);
			include("footer.php");
		?>
		<!---->
	<body>
</html>