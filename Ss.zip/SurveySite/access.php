<?php
	session_start();
	if (isset($_SESSION['rememberme'])){
		setcookie("username", $_SESSION['username'], time()+86400*60, "/","", 0);
	}
	header('location: dashboard.php');
?>