<?php
	session_start();
	if (isset($_GET['sID'])) {
		$uID=$_SESSION['id'];
		$con=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
		$id=$_GET['sID'];
		$q = "UPDATE `surveys` SET `isClosed`=!`isClosed` WHERE userID=$uID AND surveyID= $id;";
		$res = mysqli_query($con,$q);
		$q = "SELECT * FROM `surveys` WHERE surveyID= $id;";
		$res= mysqli_query($con,$q);
		$surv= mysqli_fetch_array($res, MYSQLI_NUM);
		if ($surv[9]!=0) {
			echo "<i class='fas'>&#xf3c1;</i>";
		}
		else {
			echo "<i class='fas'>&#xf023;</i>";
		}
	}
	else echo "???";
	mysqli_close($con);
?>