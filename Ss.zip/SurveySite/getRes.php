<?php
	$resID=0;
	//check $_GET value.
	if (isset($_GET['rid']) && isset($_GET['uid'])) {
		$resID = $_GET['rid'];
		$userID= $_GET['uid'];
	}
	else {
		exit();
	}
	//connect to Database
	$conn=mysqli_connect("localhost", "root", "","surveysite") or die("can't connect database");
	//get response info.
	$query="SELECT * FROM `responses` WHERE `userID`=$userID AND `responseID`=$resID ORDER BY `date` DESC";
	$result= mysqli_query($conn,$query);
	while ($row = mysqli_fetch_array($result,MYSQLI_NUM)) {
		//get title.
		$surveyID=$row[2];
		$query="SELECT * FROM `surveys` WHERE surveyID='$surveyID'";
		$title= mysqli_query($conn,$query);
		$svTitle= mysqli_fetch_array($title, MYSQLI_NUM)[1];
		//print Title.
		echo "<h1 class='is-size-3'><b>"."$svTitle"."</b></h1>";
		//get total questions.
		$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' AND questionType <> 'none'";
		$question= mysqli_query($conn,$query);
		$totalQuestions= $question->num_rows;
		echo "<h1>Total question: $totalQuestions </h1>";
		//get all responses.
		$query="SELECT * FROM `option_responses` WHERE `responseID`=$row[0]";
		$resp= mysqli_query($conn,$query);
		//create array of responses.
		$qr =[];
		while ($r = mysqli_fetch_array($resp,MYSQLI_NUM)) {
			//echo "$r[0] | $r[1] | $r[2] <br/>";
			$qr[$r[1]][$r[2]]=$r[2];
		}
		for ($i=0; $i<=$totalQuestions; $i++) {
			if (!isset($qr[$i])) $qr[$i]='';
		}
		$query="SELECT * FROM `text_responses` WHERE `responseID`=$row[0]";
		$resp= mysqli_query($conn,$query);
		while ($r = mysqli_fetch_array($resp,MYSQLI_NUM)) {
			//echo "$r[0] | $r[1] | $r[2] <br/>";
			$qr[$r[1]]=$r[2];
		}
		//get questions info and print result.
		$i=0;
		$para=0;
		$query="SELECT * FROM `questions` WHERE surveyID='$surveyID' ORDER BY `questionID` ASC";
		$r= mysqli_query($conn,$query);
		while ($q= mysqli_fetch_array($r, MYSQLI_NUM)) {
			if ($q[2] == 'none') {
				$para++;
				continue;
			}
			$qNumTemp = $q[0] - $para;
			echo "
			<h1 class='box square-box has-background-grey has-text-white spaced-out-wide'>
				Question $qNumTemp: $q[3]";
			if ($q[2]=='yn') {
				?>
					<p class="subtitle has-text-white is-size-7" style="text-transform: uppercase;">
						<?php echo "Question type: Yes No Question"?>
					</p>
				<?php
			}
			else {
				?>
					<p class="subtitle has-text-white is-size-7" style="text-transform: uppercase;">
						<?php echo "Question type: $q[2]"?>
					</p>
				<?php
			}
			echo "</h1>";
			if (!is_array($qr[$q[0]])) {
				echo "<b>"."Your response:"."</b>";
				echo "<h1 class='square-box has-text-black has-text-weight-light is-size-6'>".$qr[$q[0]]."</h1>";
			}
			else {
				echo "<b>"."Your response:"."</b>";
				foreach ($qr[$q[0]] as $value) {
					$qID=$q[0];
					$query="SELECT * FROM `answers` WHERE surveyID='$surveyID' AND questionID='$qID' AND answerID='$value';";
					$a = mysqli_query($conn,$query);
					$aText= mysqli_fetch_array($a, MYSQLI_NUM);
					echo "<h1 class='square-box has-text-black has-text-weight-light is-size-6'>".$aText[4]."</h1>";
				}
			}
			echo "<br/>";
		}
	}
	mysqli_close($conn);
?>